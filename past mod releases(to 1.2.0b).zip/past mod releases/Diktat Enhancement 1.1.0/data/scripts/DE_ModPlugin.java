package data.scripts;

import com.fs.starfarer.api.BaseModPlugin;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.*;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.characters.FullName;
import com.fs.starfarer.api.characters.ImportantPeopleAPI;
import com.fs.starfarer.api.impl.campaign.fleets.FleetFactoryV3;
import com.fs.starfarer.api.impl.campaign.fleets.FleetParamsV3;
import com.fs.starfarer.api.impl.campaign.ids.*;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.impl.campaign.skills.OfficerTraining;
import exerelin.campaign.SectorManager;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.listeners.ColonyDecivListener;



public class DE_ModPlugin extends BaseModPlugin {
    public static boolean isExerelin = false;
    public static boolean isPAGSM = Global.getSettings().getModManager().isModEnabled("PAGSM");
    public static String TTAmbassador = "TTambassador";
    public static String PLAmbassador = "PLambassador";
    public static String MIDGARDADMIN = "midgard_admin";



    private static void initDE() {
        new Gen().generate(Global.getSector());
    }

    // Incan god of snow - Lonely TT colony
    private static void initTriTachMarketsYma() {
        SectorAPI sector = Global.getSector();
        StarSystemAPI system = sector.getStarSystem("Yma");
        PlanetAPI khuno = system.addPlanet("khuno", system.getEntityById("yma"), "Khuno", "frozen", 280, 150, 12000, 1000);
        khuno.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "asharu"));
        khuno.applySpecChanges();
        khuno.setInteractionImage("illustrations", "vacuum_colony");
        khuno.setCustomDescriptionId("planet_khuno");
    }

    // Aztec god of snow - Former TT staging point
    private static void initTriTachMarketsAztlan() {
        SectorAPI sector = Global.getSector();
        StarSystemAPI system = sector.getStarSystem("Aztlan");
        PlanetAPI qui = system.addPlanet("qui", system.getEntityById("aztlan"), "Itztlacoliuhqui", "frozen", 280, 150, 6000, 400);
        qui.setCustomDescriptionId("planet_qui");
        qui.getMarket().addCondition(Conditions.DECIVILIZED);
        qui.getMarket().addCondition(Conditions.VERY_COLD);
        qui.getMarket().addCondition(Conditions.DARK);
        qui.getMarket().addCondition(Conditions.NO_ATMOSPHERE);
        qui.getMarket().addCondition(Conditions.ORE_MODERATE);
        qui.getMarket().addCondition(Conditions.RARE_ORE_SPARSE);
        qui.getMarket().addCondition(Conditions.RUINS_WIDESPREAD);
    }

    // Islamic term for snow/drugs - quite fitting really
    private static void initTriTachMarketsZagan() {
        SectorAPI sector = Global.getSector();
        StarSystemAPI system = sector.getStarSystem("Zagan");
        PlanetAPI kukayin = system.addPlanet("kukayin", system.getEntityById("zagan"), "Kukayin", "tundra", 280, 150, 7000, 300);
        kukayin.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "volturn"));
        kukayin.applySpecChanges();
        kukayin.setInteractionImage("illustrations", "cargo_loading");
        kukayin.setCustomDescriptionId("planet_kukayin");
    }

    // Irish god of snow - Binary(as best as can be executed ingame)
    private static void initTriTachMarketsHybrasil() {
        SectorAPI sector = Global.getSector();
        StarSystemAPI system = sector.getStarSystem("Hybrasil");

        PlanetAPI cailleach = system.addPlanet("cailleach", system.getEntityById("hybrasil"), "Cailleach", "frozen", 280, 150, 10000, 300);
        cailleach.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "volturn"));
        cailleach.applySpecChanges();
        cailleach.setInteractionImage("illustrations", "cargo_loading");
        cailleach.setCustomDescriptionId("planet_cailleach");

        PlanetAPI bheur = system.addPlanet("bheur", system.getEntityById("cailleach"), "Bheur", "frozen", 280, 150, 500, 40);
        bheur.setCustomDescriptionId("planet_bheur");
        bheur.getMarket().addCondition(Conditions.VERY_COLD);
        bheur.getMarket().addCondition(Conditions.DARK);
        bheur.getMarket().addCondition(Conditions.NO_ATMOSPHERE);
        bheur.getMarket().addCondition(Conditions.VOLATILES_ABUNDANT);
        bheur.getMarket().addCondition(Conditions.ORE_MODERATE);
        bheur.getMarket().addCondition(Conditions.RARE_ORE_MODERATE);
    }

    private static void initTriTachMarketsTyle() {
        SectorAPI sector = Global.getSector();
        StarSystemAPI system = sector.getStarSystem("Tyle");
        PlanetAPI aisoyim = system.addPlanet("aisoyim", system.getEntityById("tyle"), "Aisoyimstan", "rocky_ice", 280, 150, 7000, 300);
        aisoyim.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "volturn"));
        aisoyim.applySpecChanges();
        aisoyim.setInteractionImage("illustrations", "cargo_loading");
        aisoyim.setCustomDescriptionId("planet_aisoyim");
    }

    @Override
    public void onNewGame() {
        boolean haveNexerelin = Global.getSettings().getModManager().isModEnabled("nexerelin");
        if (!haveNexerelin || SectorManager.getCorvusMode()) {
            initDE();
            initTriTachMarketsYma();
            initTriTachMarketsAztlan();
            initTriTachMarketsZagan();
            initTriTachMarketsHybrasil();
            initTriTachMarketsTyle();
        }
    }

    // Some conditions(eg. Large Refugee Population) are not added as the game already adds them as hidden conditions that affect markets without explicitly showing themselves on the intel screen
    private static void initAskonia() {
        SectorAPI sector = Global.getSector();
        StarSystemAPI system = sector.getStarSystem("Askonia");
        SectorEntityToken a1 = system.getEntityById("sindria");
        if (!isPAGSM) {
            a1.getMarket().addCondition("DE_Lobsters");
            a1.getMarket().addCondition("DE_Orbitalworks");
            a1.getMarket().addCondition("DE_Patrioticfervor");
        } else {
            a1.getMarket().addCondition("DE_Lobsters_PAGSM");
            a1.getMarket().addCondition("DE_Orbitalworks_PAGSM");
            a1.getMarket().addCondition("DE_Patrioticfervor_PAGSM");
        }
        a1.getMarket().addIndustry(Industries.STARFORTRESS);
        a1.getMarket().removeIndustry(Industries.BATTLESTATION, MarketAPI.MarketInteractionMode.LOCAL, true);
        // a1.getMarket().addIndustry(Industries.PLANETARYSHIELD); // Add if you want to suffer
        a1.getMarket().getIndustry(Industries.HIGHCOMMAND).setSpecialItem(new SpecialItemData(Items.CRYOARITHMETIC_ENGINE, null));
        a1.getMarket().getIndustry(Industries.FUELPROD).setImproved(true); // Lion powers - charisma isn't anything to scoff at

        ImportantPeopleAPI ip = Global.getSector().getImportantPeople();

        // Admiral
        PersonAPI admiral = Global.getSector().getFaction("sindrian_diktat").createRandomPerson(FullName.Gender.MALE);
        admiral.setId("de_admiral");
        admiral.setPostId(Ranks.POST_FLEET_COMMANDER);
        admiral.setRankId(Ranks.POST_FLEET_COMMANDER);
        admiral.setPersonality(Personalities.AGGRESSIVE);
        admiral.getStats().setLevel(9);
        // fleet commander stuff
        admiral.getStats().setSkillLevel(Skills.COORDINATED_MANEUVERS, 1);
        admiral.getStats().setSkillLevel(Skills.CREW_TRAINING, 1);
        admiral.getStats().setSkillLevel(Skills.OFFICER_TRAINING, 1);
        admiral.getStats().setSkillLevel(Skills.SUPPORT_DOCTRINE, 1);
        admiral.getStats().setSkillLevel(Skills.TACTICAL_DRILLS, 1);
        admiral.getStats().setSkillLevel(Skills.OFFICER_MANAGEMENT, 1);
        // officer stuff
        admiral.getStats().setSkillLevel(Skills.COMBAT_ENDURANCE, 3);
        admiral.getStats().setSkillLevel(Skills.MISSILE_SPECIALIZATION, 3);
        admiral.getStats().setSkillLevel(Skills.TARGET_ANALYSIS, 3);
        admiral.getStats().setSkillLevel(Skills.FIELD_MODULATION, 3);
        admiral.getStats().setSkillLevel(Skills.IMPACT_MITIGATION, 3);
        admiral.getStats().setSkillLevel(Skills.HELMSMANSHIP, 3);
        admiral.getStats().setSkillLevel(Skills.DAMAGE_CONTROL, 3);
        admiral.getStats().setSkillLevel(Skills.ENERGY_WEAPON_MASTERY, 3);
        admiral.getStats().setSkillLevel(Skills.POLARIZED_ARMOR, 3);
        ip.addPerson(admiral);

        // I have to make every single one of these bozos manually
        PersonAPI person1 = Global.getSector().getFaction("sindrian_diktat").createRandomPerson(FullName.Gender.ANY);
        person1.setId("de_generic_officer1");
        person1.setPostId(Ranks.POST_OFFICER);
        person1.setRankId(Ranks.POST_OFFICER);
        person1.setPersonality(Personalities.AGGRESSIVE);
        person1.getStats().setSkillLevel(Skills.COMBAT_ENDURANCE, 2);
        person1.getStats().setSkillLevel(Skills.MISSILE_SPECIALIZATION, 3);
        person1.getStats().setSkillLevel(Skills.TARGET_ANALYSIS, 3);
        person1.getStats().setSkillLevel(Skills.FIELD_MODULATION, 3);
        person1.getStats().setSkillLevel(Skills.IMPACT_MITIGATION, 3);
        person1.getStats().setSkillLevel(Skills.HELMSMANSHIP, 2);
        person1.getStats().setSkillLevel(Skills.DAMAGE_CONTROL, 2);
        person1.getStats().setLevel(7);

        PersonAPI person2 = Global.getSector().getFaction("sindrian_diktat").createRandomPerson(FullName.Gender.ANY);
        person2.setId("de_generic_officer2");
        person2.setPostId(Ranks.POST_OFFICER);
        person2.setRankId(Ranks.POST_OFFICER);
        person2.setPersonality(Personalities.AGGRESSIVE);
        person2.getStats().setSkillLevel(Skills.COMBAT_ENDURANCE, 2);
        person2.getStats().setSkillLevel(Skills.MISSILE_SPECIALIZATION, 3);
        person2.getStats().setSkillLevel(Skills.TARGET_ANALYSIS, 3);
        person2.getStats().setSkillLevel(Skills.FIELD_MODULATION, 3);
        person2.getStats().setSkillLevel(Skills.IMPACT_MITIGATION, 3);
        person2.getStats().setSkillLevel(Skills.HELMSMANSHIP, 2);
        person2.getStats().setSkillLevel(Skills.DAMAGE_CONTROL, 2);
        person2.getStats().setLevel(7);

        PersonAPI person3 = Global.getSector().getFaction("sindrian_diktat").createRandomPerson(FullName.Gender.ANY);
        person3.setId("de_generic_officer3");
        person3.setPostId(Ranks.POST_OFFICER);
        person3.setRankId(Ranks.POST_OFFICER);
        person3.setPersonality(Personalities.AGGRESSIVE);
        person3.getStats().setSkillLevel(Skills.COMBAT_ENDURANCE, 2);
        person3.getStats().setSkillLevel(Skills.MISSILE_SPECIALIZATION, 3);
        person3.getStats().setSkillLevel(Skills.TARGET_ANALYSIS, 3);
        person3.getStats().setSkillLevel(Skills.FIELD_MODULATION, 3);
        person3.getStats().setSkillLevel(Skills.IMPACT_MITIGATION, 3);
        person3.getStats().setSkillLevel(Skills.HELMSMANSHIP, 2);
        person3.getStats().setSkillLevel(Skills.DAMAGE_CONTROL, 2);
        person3.getStats().setLevel(7);

        PersonAPI person4 = Global.getSector().getFaction("sindrian_diktat").createRandomPerson(FullName.Gender.ANY);
        person4.setId("de_generic_officer4");
        person4.setPostId(Ranks.POST_OFFICER);
        person4.setRankId(Ranks.POST_OFFICER);
        person4.setPersonality(Personalities.AGGRESSIVE);
        person4.getStats().setSkillLevel(Skills.COMBAT_ENDURANCE, 2);
        person4.getStats().setSkillLevel(Skills.MISSILE_SPECIALIZATION, 3);
        person4.getStats().setSkillLevel(Skills.TARGET_ANALYSIS, 3);
        person4.getStats().setSkillLevel(Skills.FIELD_MODULATION, 3);
        person4.getStats().setSkillLevel(Skills.IMPACT_MITIGATION, 3);
        person4.getStats().setSkillLevel(Skills.HELMSMANSHIP, 2);
        person4.getStats().setSkillLevel(Skills.DAMAGE_CONTROL, 2);
        person4.getStats().setLevel(7);

        PersonAPI person5 = Global.getSector().getFaction("sindrian_diktat").createRandomPerson(FullName.Gender.ANY);
        person5.setId("de_generic_officer5");
        person5.setPostId(Ranks.POST_OFFICER);
        person5.setRankId(Ranks.POST_OFFICER);
        person5.setPersonality(Personalities.AGGRESSIVE);
        person5.getStats().setSkillLevel(Skills.COMBAT_ENDURANCE, 2);
        person5.getStats().setSkillLevel(Skills.MISSILE_SPECIALIZATION, 3);
        person5.getStats().setSkillLevel(Skills.TARGET_ANALYSIS, 3);
        person5.getStats().setSkillLevel(Skills.FIELD_MODULATION, 3);
        person5.getStats().setSkillLevel(Skills.IMPACT_MITIGATION, 3);
        person5.getStats().setSkillLevel(Skills.HELMSMANSHIP, 2);
        person5.getStats().setSkillLevel(Skills.DAMAGE_CONTROL, 2);
        person5.getStats().setLevel(7);

        PersonAPI person6 = Global.getSector().getFaction("sindrian_diktat").createRandomPerson(FullName.Gender.ANY);
        person6.setId("de_generic_officer1");
        person6.setPostId(Ranks.POST_OFFICER);
        person6.setRankId(Ranks.POST_OFFICER);
        person6.setPersonality(Personalities.AGGRESSIVE);
        person6.getStats().setSkillLevel(Skills.COMBAT_ENDURANCE, 2);
        person6.getStats().setSkillLevel(Skills.MISSILE_SPECIALIZATION, 3);
        person6.getStats().setSkillLevel(Skills.TARGET_ANALYSIS, 3);
        person6.getStats().setSkillLevel(Skills.FIELD_MODULATION, 3);
        person6.getStats().setSkillLevel(Skills.IMPACT_MITIGATION, 3);
        person6.getStats().setSkillLevel(Skills.HELMSMANSHIP, 2);
        person6.getStats().setSkillLevel(Skills.DAMAGE_CONTROL, 2);
        person6.getStats().setLevel(7);

        PersonAPI reckless1 = Global.getSector().getFaction("sindrian_diktat").createRandomPerson(FullName.Gender.ANY);
        reckless1.setId("de_reckless1");
        reckless1.setPostId(Ranks.POST_OFFICER);
        reckless1.setRankId(Ranks.POST_OFFICER);
        reckless1.setPersonality(Personalities.RECKLESS);
        reckless1.getStats().setSkillLevel(Skills.COMBAT_ENDURANCE, 3);
        reckless1.getStats().setSkillLevel(Skills.MISSILE_SPECIALIZATION, 3);
        reckless1.getStats().setSkillLevel(Skills.TARGET_ANALYSIS, 3);
        reckless1.getStats().setSkillLevel(Skills.FIELD_MODULATION, 3);
        reckless1.getStats().setSkillLevel(Skills.IMPACT_MITIGATION, 2);
        reckless1.getStats().setSkillLevel(Skills.HELMSMANSHIP, 2);
        reckless1.getStats().setSkillLevel(Skills.DAMAGE_CONTROL, 2);
        reckless1.getStats().setLevel(7);

        PersonAPI reckless2 = Global.getSector().getFaction("sindrian_diktat").createRandomPerson(FullName.Gender.ANY);
        reckless2.setId("de_reckless2");
        reckless2.setPostId(Ranks.POST_OFFICER);
        reckless2.setRankId(Ranks.POST_OFFICER);
        reckless2.setPersonality(Personalities.RECKLESS);
        reckless2.getStats().setSkillLevel(Skills.COMBAT_ENDURANCE, 3);
        reckless2.getStats().setSkillLevel(Skills.MISSILE_SPECIALIZATION, 3);
        reckless2.getStats().setSkillLevel(Skills.TARGET_ANALYSIS, 3);
        reckless2.getStats().setSkillLevel(Skills.FIELD_MODULATION, 3);
        reckless2.getStats().setSkillLevel(Skills.IMPACT_MITIGATION, 2);
        reckless2.getStats().setSkillLevel(Skills.HELMSMANSHIP, 2);
        reckless2.getStats().setSkillLevel(Skills.DAMAGE_CONTROL, 2);
        reckless2.getStats().setLevel(7);

        PersonAPI reckless3 = Global.getSector().getFaction("sindrian_diktat").createRandomPerson(FullName.Gender.ANY);
        reckless3.setId("de_reckless3");
        reckless3.setPostId(Ranks.POST_OFFICER);
        reckless3.setRankId(Ranks.POST_OFFICER);
        reckless3.setPersonality(Personalities.RECKLESS);
        reckless3.getStats().setSkillLevel(Skills.COMBAT_ENDURANCE, 3);
        reckless3.getStats().setSkillLevel(Skills.MISSILE_SPECIALIZATION, 3);
        reckless3.getStats().setSkillLevel(Skills.TARGET_ANALYSIS, 3);
        reckless3.getStats().setSkillLevel(Skills.FIELD_MODULATION, 3);
        reckless3.getStats().setSkillLevel(Skills.IMPACT_MITIGATION, 2);
        reckless3.getStats().setSkillLevel(Skills.HELMSMANSHIP, 2);
        reckless3.getStats().setSkillLevel(Skills.DAMAGE_CONTROL, 2);
        reckless3.getStats().setLevel(7);

        // A script to protect officers from crewcapture which im not using for now
        /*
        @Override
        public void reportShownInteractionDialog (InteractionDialogAPI dialog) {
            if (dialog.getPlugin() instanceof CaptiveInteractionDialogPlugin) {
                for (EveryFrameScript script : Global.getSector().getScripts()) {
                    if (script instanceof LootAddScript) {
                        List<PersonAPI> LootAddScript= ((LootAddScript) script).captiveOfficers;
                        LootAddScript.remove(Global.getSector().getImportantPeople().getPerson("de_admiral"));
                        LootAddScript.remove(Global.getSector().getImportantPeople().getPerson("de_generic_officer1"));
                        LootAddScript.remove(Global.getSector().getImportantPeople().getPerson("de_generic_officer2"));
                        LootAddScript.remove(Global.getSector().getImportantPeople().getPerson("de_generic_officer3"));
                        LootAddScript.remove(Global.getSector().getImportantPeople().getPerson("de_generic_officer4"));
                        LootAddScript.remove(Global.getSector().getImportantPeople().getPerson("de_generic_officer5"));
                        LootAddScript.remove(Global.getSector().getImportantPeople().getPerson("de_reckless1"));
                        LootAddScript.remove(Global.getSector().getImportantPeople().getPerson("de_reckless2"));
                        LootAddScript.remove(Global.getSector().getImportantPeople().getPerson("de_reckless3"));
                    }
                }
            }
        } */

        // Should add superfleet 1 to Sindria(The Pride of The Executor)(or The Pride of The Manager for PAGSM)
        if (!isPAGSM) {
            FleetParamsV3 params = new FleetParamsV3(
                    a1.getMarket(), // add a source(has to be from a MarketAPI)
                    null, // loc in hyper; don't need if have market
                    "lions_guard",
                    2f, // quality override route.getQualityOverride()
                    FleetTypes.PATROL_LARGE,
                    1f, // combatPts(minimal so special ships can be added)(1000f otherwise)
                    0f, // freighterPts
                    0f, // tankerPts
                    0f, // transportPts
                    0f, // linerPts
                    0f, // utilityPts
                    0f// qualityMod
            );
            params.officerNumberMult = 2f;
            params.officerLevelBonus = 4;
            params.officerNumberBonus = 4;
            params.officerLevelLimit = 10; // Global.getSettings().getInt("officerMaxLevel") + (int) OfficerTraining.MAX_LEVEL_BONUS;
            params.modeOverride = FactionAPI.ShipPickMode.PRIORITY_THEN_ALL;
            params.averageSMods = 1;
            params.commander = Global.getSector().getImportantPeople().getPerson("de_admiral");
            params.flagshipVariantId = "odyssey_LClaw";
            CampaignFleetAPI fleet = FleetFactoryV3.createFleet(params);
            if (fleet == null || fleet.isEmpty()) return;
            fleet.setFaction("sindrian_diktat", true);
            fleet.getFlagship().setShipName("SDS Hand of Andrada");
            //fleet.setCommander(Global.getSector().getImportantPeople().getPerson("de_admiral"));
            //fleet.getFlagship().setOwner(1);
            fleet.getFlagship().setId("odyssey_LClaw"); // executor
            fleet.getFleetData().addFleetMember("odyssey_LClaw").setCaptain(person1);
            fleet.getFleetData().addFleetMember("odyssey_LClaw").setCaptain(person2);
            fleet.getFleetData().addFleetMember("odyssey_LClaw");
            fleet.getFleetData().addFleetMember("odyssey_LClaw");
            fleet.getFleetData().addFleetMember("conquest_LClaw").setCaptain(person3);
            fleet.getFleetData().addFleetMember("conquest_LClaw").setCaptain(person4);
            fleet.getFleetData().addFleetMember("conquest_LClaw").setCaptain(person5);
            fleet.getFleetData().addFleetMember("conquest_LClaw");
            fleet.getFleetData().addFleetMember("conquest_LClaw");
            fleet.getFleetData().addFleetMember("eagle_LMane");
            fleet.getFleetData().addFleetMember("eagle_LMane");
            fleet.getFleetData().addFleetMember("eagle_LMane");
            fleet.getFleetData().addFleetMember("eagle_LMane");
            fleet.getFleetData().addFleetMember("eagle_LMane");
            fleet.getFleetData().addFleetMember("champion_LMane");
            fleet.getFleetData().addFleetMember("champion_LMane");
            fleet.getFleetData().addFleetMember("champion_LMane");
            fleet.getFleetData().addFleetMember("champion_LMane");
            fleet.getFleetData().addFleetMember("champion_LMane");
            fleet.getFleetData().addFleetMember("gryphon_LPatience").setCaptain(person6);
            fleet.getFleetData().addFleetMember("heron_LPatience");
            fleet.getFleetData().addFleetMember("heron_LPatience");
            fleet.getFleetData().addFleetMember("heron_LPatience");
            fleet.getFleetData().addFleetMember("heron_LPatience");
            fleet.getFleetData().addFleetMember("heron_LPatience");
            fleet.getFleetData().addFleetMember("fury_LFury").setCaptain(reckless1);
            fleet.getFleetData().addFleetMember("fury_LFury").setCaptain(reckless2);
            fleet.getFleetData().addFleetMember("fury_LFury").setCaptain(reckless3);
            fleet.getFleetData().addFleetMember("fury_LFury");
            fleet.getFleetData().addFleetMember("fury_LFury");
            fleet.getFleetData().addFleetMember("hammerhead_LMane");
            fleet.getFleetData().addFleetMember("hammerhead_LMane");
            fleet.getFleetData().addFleetMember("hammerhead_LMane");
            fleet.getFleetData().addFleetMember("hammerhead_LMane");
            fleet.getFleetData().addFleetMember("hammerhead_LMane");
            fleet.getFleetData().addFleetMember("sunder_LPatience");
            fleet.getFleetData().addFleetMember("sunder_LPatience");
            fleet.getFleetData().addFleetMember("sunder_LPatience");
            fleet.getFleetData().addFleetMember("monitor_LFortitude");
            fleet.getFleetData().addFleetMember("monitor_LFortitude");
            fleet.getFleetData().addFleetMember("monitor_LFortitude");
            fleet.getFleetData().addFleetMember("monitor_LFortitude");
            fleet.getFleetData().addFleetMember("monitor_LFortitude");
            fleet.getFleetData().addFleetMember("centurion_LFortitude");
            fleet.getFleetData().addFleetMember("centurion_LFortitude");
            fleet.getFleetData().addFleetMember("centurion_LFortitude");
            fleet.getFleetData().addFleetMember("centurion_LFortitude");
            fleet.getFleetData().addFleetMember("centurion_LFortitude");
            fleet.setNoFactionInName(true);
            fleet.setName("The Pride of The Executor");
            // a1.getMarket().getContainingLocation().addEntity(fleet);
            a1.getContainingLocation().addEntity(fleet);
            fleet.setAI(Global.getFactory().createFleetAI(fleet));
            fleet.setMarket(a1.getMarket());
            fleet.setLocation(a1.getLocation().x, a1.getLocation().y);
            fleet.setFacing((float) Math.random() * 360f);
            fleet.getAI().addAssignment(FleetAssignment.DEFEND_LOCATION, a1, (float) Math.random() * 90000f, null);
        } else {
            // The Pride of The Manager
            FleetParamsV3 params = new FleetParamsV3(
                    a1.getMarket(), // add a source(has to be from a MarketAPI)
                    null, // loc in hyper; don't need if have market
                    "lions_guard",
                    2f, // quality override route.getQualityOverride()
                    FleetTypes.PATROL_LARGE,
                    1f, // combatPts(minimal so special ships can be added)(1000f otherwise)
                    0f, // freighterPts
                    0f, // tankerPts
                    0f, // transportPts
                    0f, // linerPts
                    0f, // utilityPts
                    0f// qualityMod
            );
            params.officerNumberMult = 2f;
            params.officerLevelBonus = 4;
            params.officerNumberBonus = 4;
            params.officerLevelLimit = 10; // Global.getSettings().getInt("officerMaxLevel") + (int) OfficerTraining.MAX_LEVEL_BONUS;
            params.modeOverride = FactionAPI.ShipPickMode.PRIORITY_THEN_ALL;
            params.averageSMods = 2;
            params.commander = Global.getSector().getImportantPeople().getPerson("de_admiral");
            params.flagshipVariantId = "sfcsuperiapetus_Mixed";
            CampaignFleetAPI fleet = FleetFactoryV3.createFleet(params);
            if (fleet == null || fleet.isEmpty()) return;
            fleet.setFaction("sindrian_diktat", true);
            fleet.getFlagship().setShipName("SFS Hand of Andrada");
            //fleet.setCommander(Global.getSector().getImportantPeople().getPerson("de_admiral"));
            //fleet.getFlagship().setOwner(1);
            fleet.getFlagship().setId("sfcsuperiapetus_Mixed");
            fleet.getFleetData().addFleetMember("sfcskyrend_Beamer").setCaptain(person1);
            fleet.getFleetData().addFleetMember("sfcskyrend_Beamer").setCaptain(person2);
            fleet.getFleetData().addFleetMember("sfcskyrend_Beamer");
            fleet.getFleetData().addFleetMember("sfcepimetheus_Pulser");
            fleet.getFleetData().addFleetMember("sfciapetus_Mixed").setCaptain(person3);
            fleet.getFleetData().addFleetMember("sfciapetus_Mixed").setCaptain(person4);
            fleet.getFleetData().addFleetMember("sfciapetus_Mixed").setCaptain(person5);
            fleet.getFleetData().addFleetMember("sfciapetus_Mixed");
            fleet.getFleetData().addFleetMember("sfciapetus_Mixed");
            fleet.getFleetData().addFleetMember("sfccrius_Pressure");
            fleet.getFleetData().addFleetMember("sfccrius_Pressure");
            fleet.getFleetData().addFleetMember("sfccrius_Pressure");
            fleet.getFleetData().addFleetMember("eagle_LMane");
            fleet.getFleetData().addFleetMember("eagle_LMane");
            fleet.getFleetData().addFleetMember("sfccrius_Pressure");
            fleet.getFleetData().addFleetMember("sfccrius_Pressure");
            fleet.getFleetData().addFleetMember("champion_LMane");
            fleet.getFleetData().addFleetMember("champion_LMane");
            fleet.getFleetData().addFleetMember("champion_LMane");
            fleet.getFleetData().addFleetMember("gryphon_LPatience").setCaptain(person6);
            fleet.getFleetData().addFleetMember("sfcclepsydra_Standard");
            fleet.getFleetData().addFleetMember("sfcclepsydra_Standard");
            fleet.getFleetData().addFleetMember("sfcarke_Suppression");
            fleet.getFleetData().addFleetMember("sfcarke_Suppression");
            fleet.getFleetData().addFleetMember("sfcarke_Suppression");
            fleet.getFleetData().addFleetMember("fury_LFury").setCaptain(reckless1);
            fleet.getFleetData().addFleetMember("fury_LFury").setCaptain(reckless2);
            fleet.getFleetData().addFleetMember("fury_LFury").setCaptain(reckless3);
            fleet.getFleetData().addFleetMember("fury_LFury");
            fleet.getFleetData().addFleetMember("fury_LFury");
            fleet.getFleetData().addFleetMember("hammerhead_LMane");
            fleet.getFleetData().addFleetMember("hammerhead_LMane");
            fleet.getFleetData().addFleetMember("hammerhead_LMane");
            fleet.getFleetData().addFleetMember("hammerhead_LMane");
            fleet.getFleetData().addFleetMember("hammerhead_LMane");
            fleet.getFleetData().addFleetMember("sunder_LPatience");
            fleet.getFleetData().addFleetMember("sunder_LPatience");
            fleet.getFleetData().addFleetMember("sunder_LPatience");
            fleet.getFleetData().addFleetMember("monitor_LFortitude");
            fleet.getFleetData().addFleetMember("monitor_LFortitude");
            fleet.getFleetData().addFleetMember("monitor_LFortitude");
            fleet.getFleetData().addFleetMember("monitor_LFortitude");
            fleet.getFleetData().addFleetMember("monitor_LFortitude");
            fleet.getFleetData().addFleetMember("centurion_LFortitude");
            fleet.getFleetData().addFleetMember("centurion_LFortitude");
            fleet.getFleetData().addFleetMember("centurion_LFortitude");
            fleet.getFleetData().addFleetMember("centurion_LFortitude");
            fleet.getFleetData().addFleetMember("centurion_LFortitude");
            fleet.setNoFactionInName(true);
            fleet.setName("The Pride of The Manager");
            // a1.getMarket().getContainingLocation().addEntity(fleet);
            a1.getContainingLocation().addEntity(fleet);
            fleet.setAI(Global.getFactory().createFleetAI(fleet));
            fleet.setMarket(a1.getMarket());
            fleet.setLocation(a1.getLocation().x, a1.getLocation().y);
            fleet.setFacing((float) Math.random() * 360f);
            fleet.getAI().addAssignment(FleetAssignment.DEFEND_LOCATION, a1, (float) Math.random() * 90000f, null);
        }

        MarketAPI market = null;
        SectorEntityToken a2 = system.getEntityById("volturn");
        market = a2.getMarket();
        a2.getMarket().addCondition(Conditions.DISSIDENT);
        a2.getMarket().addCondition(Conditions.VICE_DEMAND);
        a1.getMarket().removeIndustry(Industries.GROUNDDEFENSES, MarketAPI.MarketInteractionMode.LOCAL, true);
        a2.getMarket().addIndustry(Industries.HEAVYBATTERIES);
        a2.getMarket().getIndustry(Industries.LIGHTINDUSTRY).setSpecialItem(new SpecialItemData(Items.BIOFACTORY_EMBRYO, null));
        //ColonyDecivListener().reportColonyDecivilized(a2.getMarket(), true); // idk what this listener does
        // Should implement the angry titan lober stuff(with and without PAGSM)(currently unused)
        /*if (!isPAGSM) {
            if (market == null) {
                a2.getMarket().removeCondition("DE_Megafauna");
                a2.getMarket().addCondition("DE_Titanlober"); // pre-colonization
            }
            if (market != null && a2.getMarket().hasCondition("DE_Titanlober") && "sindrian_diktat".equals(market.getFactionId())) {
                a2.getMarket().removeCondition("DE_Titanlober"); // no megafauna for diktat...I wonder why
            } else if (market != null && a2.getMarket().hasCondition("DE_Titanlober")) {
                a2.getMarket().removeCondition("DE_Titanlober");
                a2.getMarket().addCondition("DE_Megafauna"); // post-colonization
            }
        } else {
            if (market == null) {
                a2.getMarket().removeCondition("DE_MegafaunaPAGSM");
                a2.getMarket().addCondition("DE_Titanlober"); // pre-colonization
            }
            if (market != null && a2.getMarket().hasCondition("DE_Titanlober") && "sindrian_diktat".equals(market.getFactionId())) {
                a2.getMarket().removeCondition("DE_Titanlober"); // volturny pacified them
            } else if (market != null && a2.getMarket().hasCondition("DE_Titanlober")) {
                a2.getMarket().removeCondition("DE_Titanlober");
                a2.getMarket().addCondition("DE_MegafaunaPAGSM"); // post-colonization
            }
        }*/
        if (!isPAGSM) {
            a2.getMarket().addCondition("DE_Patrioticfervor");
        } else {
            a2.getMarket().addCondition("DE_Patrioticfervor_PAGSM");
        }

        SectorEntityToken a3 = system.getEntityById("cruor");
        a3.getMarket().getIndustry(Industries.MINING).setSpecialItem(new SpecialItemData(Items.MANTLE_BORE, null));

        SectorEntityToken a4 = system.getEntityById("opis_mining_plat");
        if (!isPAGSM) {
            a4.getMarket().addCondition("DE_Patrioticfervor");
        } else {
            a4.getMarket().addCondition("DE_Patrioticfervor_PAGSM");
        }

        // Andrada contact info so he actually gives missions
        PersonAPI andrada = Global.getSector().getImportantPeople().getPerson("andrada");
        andrada.addTag(Tags.CONTACT_MILITARY);
        andrada.addTag(Tags.CONTACT_TRADE);
    }

    // Hi im Tri-Tach and I abuse the hell out of colony items
    private static void initHybrasilTTMarketChanges() {
        SectorAPI sector = Global.getSector();
        StarSystemAPI system = sector.getStarSystem("Hybrasil");
        SectorEntityToken h1 = system.getEntityById("culann");
        h1.getMarket().getIndustry(Industries.MILITARYBASE).setSpecialItem(new SpecialItemData(Items.CRYOARITHMETIC_ENGINE, null));
        h1.getMarket().getIndustry(Industries.REFINING).setSpecialItem(new SpecialItemData(Items.CATALYTIC_CORE, null));

        SectorEntityToken h2 = system.getEntityById("eochu_bres");
        h2.getMarket().addIndustry(Industries.HEAVYBATTERIES);
        h2.getMarket().getIndustry(Industries.LIGHTINDUSTRY).setSpecialItem(new SpecialItemData(Items.BIOFACTORY_EMBRYO, null));
        h2.getMarket().getIndustry(Industries.FARMING).setSpecialItem(new SpecialItemData(Items.SOIL_NANITES, null));
    }

    private static void initAndorMarketChanges() {
        SectorAPI sector = Global.getSector();
        StarSystemAPI system = sector.getStarSystem("Andor");
        SectorEntityToken a1 = system.getEntityById("ryzan_supercomplex");
        if (!isPAGSM) {
            a1.getMarket().addCondition("DE_Patrioticfervor");
        } else {
            a1.getMarket().addCondition("DE_Patrioticfervor_PAGSM");
        }

        SectorEntityToken a2 = system.getEntityById("andor_viewport");
        if (!isPAGSM) {
            a2.getMarket().addCondition("DE_Patrioticfervor");
        } else {
            a2.getMarket().addCondition("DE_Patrioticfervor_PAGSM");
        }
    }

    private static void addBifrost() {
        SectorAPI sector = Global.getSector();
        StarSystemAPI system = sector.getStarSystem("Valhalla");
        SectorEntityToken midgard = system.getEntityById("midgard");
        // Midgard superfleet
        FleetParamsV3 params = new FleetParamsV3(
                midgard.getMarket(), // add a source(has to be from a MarketAPI)
                null, // loc in hyper; don't need if have market
                "independent",
                2f, // quality override route.getQualityOverride()
                FleetTypes.TASK_FORCE,
                600f, // combatPts(minimal so special ships can be added)
                0f, // freighterPts
                0f, // tankerPts
                0f, // transportPts
                0f, // linerPts
                0f, // utilityPts
                0f// qualityMod
        );
        params.officerNumberMult = 2f;
        params.officerLevelBonus = 4;
        params.officerNumberBonus = 4;
        params.officerLevelLimit = Global.getSettings().getInt("officerMaxLevel") + (int) OfficerTraining.MAX_LEVEL_BONUS;
        params.modeOverride = FactionAPI.ShipPickMode.ALL;
        params.averageSMods = 1;
        params.flagshipVariantId = "paragon_Raider";
        CampaignFleetAPI fleet = FleetFactoryV3.createFleet(params);
        if (fleet == null || fleet.isEmpty()) return;
        fleet.setFaction("independent", true);
        fleet.getFlagship().setId("paragon_Raider");
        fleet.setNoFactionInName(true);
        fleet.setName("Bifrost Armada");
        midgard.getContainingLocation().addEntity(fleet);
        fleet.setAI(Global.getFactory().createFleetAI(fleet));
        fleet.setMarket(midgard.getMarket());
        fleet.setLocation(midgard.getLocation().x, midgard.getLocation().y);
        fleet.setFacing((float) Math.random() * 360f);
        fleet.getAI().addAssignment(FleetAssignment.DEFEND_LOCATION, midgard, (float) Math.random() * 90000f, null);
    }

    @Override
    public void onNewGameAfterEconomyLoad() {
        boolean haveNexerelin = Global.getSettings().getModManager().isModEnabled("nexerelin");
        if (!haveNexerelin || SectorManager.getManager().isCorvusMode()) {
            initAskonia();
            initHybrasilTTMarketChanges();
            initAndorMarketChanges();
            addBifrost();
            MarketAPI market = null;

            //adding npcs
            market = Global.getSector().getEconomy().getMarket("ryzan_supercomplex");
            ImportantPeopleAPI ip = Global.getSector().getImportantPeople();
            if (market != null) {
                // timid/tim
                PersonAPI TTambassador = Global.getFactory().createPerson();
                TTambassador.setId(TTAmbassador);
                TTambassador.setGender(FullName.Gender.MALE);
                TTambassador.setFaction(Factions.TRITACHYON);
                TTambassador.getName().setFirst("Timothy");
                TTambassador.getName().setLast("Ironheart");
                TTambassador.setPostId("TTambassadorpost");
                TTambassador.setRankId("TTambassadorrank");
                TTambassador.setImportance(PersonImportance.HIGH);
                TTambassador.setPortraitSprite("graphics/portraits/portrait_corporate08.png");
                TTambassador.setVoice(Voices.OFFICIAL);
                TTambassador.addTag(Tags.CONTACT_UNDERWORLD);
                TTambassador.addTag(Tags.CONTACT_TRADE);
                ip.addPerson(TTambassador);
                market.getCommDirectory().addPerson(TTambassador, 2);
                market.addPerson(TTambassador);

                // wmgreywind
                PersonAPI PLambassador = Global.getFactory().createPerson();
                PLambassador.setId(PLAmbassador);
                PLambassador.setGender(FullName.Gender.MALE);
                PLambassador.setFaction(Factions.PERSEAN);
                PLambassador.getName().setFirst("Bill");
                PLambassador.getName().setLast("Silvergale");
                PLambassador.setPostId("PLambassadorpost");
                PLambassador.setRankId("PLambassadorrank");
                PLambassador.setImportance(PersonImportance.HIGH);
                PLambassador.setPortraitSprite(Global.getSettings().getSpriteName("characters", PLambassador.getId()));
                //PLambassador.setPortraitSprite("graphics/portraits/portrait_league06.png");
                PLambassador.setVoice(Voices.OFFICIAL);
                PLambassador.addTag(Tags.CONTACT_MILITARY);
                PLambassador.addTag(Tags.CONTACT_TRADE);
                ip.addPerson(PLambassador);
                market.getCommDirectory().addPerson(PLambassador, 3);
                market.addPerson(PLambassador);

            }
            MarketAPI market2 = null;
            market2 = Global.getSector().getEconomy().getMarket("midgard");
            if (market2 != null) {
                PersonAPI person = Global.getSector().getFaction("independent").createRandomPerson(FullName.Gender.ANY);
                person.setId(MIDGARDADMIN);
                person.setRankId(Ranks.FACTION_LEADER);
                person.setPostId(Ranks.POST_ADMINISTRATOR);
                person.setImportance(PersonImportance.VERY_HIGH);
                person.addTag(Tags.CONTACT_TRADE);
                person.addTag(Tags.CONTACT_MILITARY);
                person.setVoice(Voices.OFFICIAL);
                person.getStats().setSkillLevel(Skills.INDUSTRIAL_PLANNING, 1);
                ip.addPerson(person);

                market2.setAdmin(person);
                market2.getCommDirectory().addPerson(person, 0);
                market2.addPerson(person);
            }
        }
    }
    /*public void onGameLoad(boolean newGame) {
        SectorAPI sector = Global.getSector();
        StarSystemAPI system = sector.getStarSystem("Askonia");
        MarketAPI market = null;
        SectorEntityToken volturn = system.getEntityById("volturn");
        market = volturn.getMarket();
        // market.hasCondition(Conditions.DECIVILIZED) // me just storing code here
        // ColonyDecivListener().reportColonyDecivilized(a2.getMarket(), true); // idk what this listener does
        // Should implement the angry titan lober stuff(with and without PAGSM)
        if (!isPAGSM) {
            if (market == null) {
                volturn.getMarket().removeCondition("DE_Megafauna");
                volturn.getMarket().addCondition("DE_Titanlober"); // pre-colonization
            }
            if (market != null && volturn.getMarket().hasCondition("DE_Titanlober") && "sindrian_diktat".equals(market.getFactionId())) {
                volturn.getMarket().removeCondition("DE_Titanlober"); // no megafauna for diktat...I wonder why
            } else if (market != null && volturn.getMarket().hasCondition("DE_Titanlober")) {
                volturn.getMarket().removeCondition("DE_Titanlober");
                volturn.getMarket().addCondition("DE_Megafauna"); // post-colonization
            }
        } else {
            if (market == null) {
                volturn.getMarket().removeCondition("DE_MegafaunaPAGSM");
                volturn.getMarket().addCondition("DE_Titanlober"); // pre-colonization
            }
            if (market != null && volturn.getMarket().hasCondition("DE_Titanlober") && "sindrian_diktat".equals(market.getFactionId())) {
                volturn.getMarket().removeCondition("DE_Titanlober"); // volturny pacified them
            } else if (market != null && volturn.getMarket().hasCondition("DE_Titanlober")) {
                volturn.getMarket().removeCondition("DE_Titanlober");
                volturn.getMarket().addCondition("DE_MegafaunaPAGSM"); // post-colonization
            }
        }
    }*/
}






