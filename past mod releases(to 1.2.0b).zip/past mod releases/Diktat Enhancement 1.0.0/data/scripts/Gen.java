package data.scripts;



import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.*;
import com.fs.starfarer.api.campaign.econ.EconomyAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Industries;
import com.fs.starfarer.api.impl.campaign.ids.Items;
import com.fs.starfarer.api.impl.campaign.ids.Submarkets;
import com.fs.starfarer.api.impl.campaign.shared.SharedData;
import data.scripts.world.systems.DE_Andor;
import data.scripts.world.systems.DE_Askonia;


import java.util.ArrayList;
import java.util.Arrays;


public class Gen implements SectorGeneratorPlugin {

    @Override
    public void generate(SectorAPI sector) {

        new DE_Andor().generate(sector);
        new DE_Askonia().generate(sector);
    }

}




