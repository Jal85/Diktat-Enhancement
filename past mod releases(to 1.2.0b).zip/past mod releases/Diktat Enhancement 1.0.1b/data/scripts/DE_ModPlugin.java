package data.scripts;

import com.fs.starfarer.api.BaseModPlugin;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.*;
import com.fs.starfarer.api.impl.campaign.ids.*;
import exerelin.campaign.SectorManager;



public class DE_ModPlugin extends BaseModPlugin {
    private static void initDE() {
        new Gen().generate(Global.getSector());
    }

    // Incan god of snow - Lonely TT colony
    private static void initTriTachMarketsYma() {
        SectorAPI sector = Global.getSector();
        StarSystemAPI system = sector.getStarSystem("Yma");
        PlanetAPI khuno = system.addPlanet("khuno", system.getEntityById("yma"), "Khuno", "frozen", 280, 150, 12000, 1000);
        khuno.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "asharu"));
        khuno.applySpecChanges();
        khuno.setInteractionImage("illustrations", "vacuum_colony");
        khuno.setCustomDescriptionId("planet_khuno");
    }

    // Aztec god of snow - Former TT staging point
    private static void initTriTachMarketsAztlan() {
        SectorAPI sector = Global.getSector();
        StarSystemAPI system = sector.getStarSystem("Aztlan");
        PlanetAPI qui = system.addPlanet("qui", system.getEntityById("aztlan"), "Itztlacoliuhqui", "frozen", 280, 150, 6000, 400);
        qui.setCustomDescriptionId("planet_qui");
        qui.getMarket().addCondition(Conditions.DECIVILIZED);
        qui.getMarket().addCondition(Conditions.VERY_COLD);
        qui.getMarket().addCondition(Conditions.DARK);
        qui.getMarket().addCondition(Conditions.NO_ATMOSPHERE);
        qui.getMarket().addCondition(Conditions.ORE_MODERATE);
        qui.getMarket().addCondition(Conditions.RARE_ORE_SPARSE);
        qui.getMarket().addCondition(Conditions.RUINS_WIDESPREAD);
    }

    // Islamic term for snow/drugs - quite fitting really
    private static void initTriTachMarketsZagan() {
        SectorAPI sector = Global.getSector();
        StarSystemAPI system = sector.getStarSystem("Zagan");
        PlanetAPI kukayin = system.addPlanet("kukayin", system.getEntityById("zagan"), "Kukayin", "tundra", 280, 150, 7000, 300);
        kukayin.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "volturn"));
        kukayin.applySpecChanges();
        kukayin.setInteractionImage("illustrations", "cargo_loading");
        kukayin.setCustomDescriptionId("planet_kukayin");
    }

    // Irish god of snow - Binary(as best as can be executed ingame)
    private static void initTriTachMarketsHybrasil() {
        SectorAPI sector = Global.getSector();
        StarSystemAPI system = sector.getStarSystem("Hybrasil");

        PlanetAPI cailleach = system.addPlanet("cailleach", system.getEntityById("hybrasil"), "Cailleach", "frozen", 280, 150, 10000, 300);
        cailleach.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "volturn"));
        cailleach.applySpecChanges();
        cailleach.setInteractionImage("illustrations", "cargo_loading");
        cailleach.setCustomDescriptionId("planet_cailleach");

        PlanetAPI bheur = system.addPlanet("bheur", system.getEntityById("cailleach"), "Bheur", "frozen", 280, 150, 200, 40);
        bheur.setCustomDescriptionId("planet_bheur");
        bheur.getMarket().addCondition(Conditions.VERY_COLD);
        bheur.getMarket().addCondition(Conditions.DARK);
        bheur.getMarket().addCondition(Conditions.NO_ATMOSPHERE);
        bheur.getMarket().addCondition(Conditions.VOLATILES_ABUNDANT);
        bheur.getMarket().addCondition(Conditions.ORE_MODERATE);
        bheur.getMarket().addCondition(Conditions.RARE_ORE_MODERATE);
    }

    private static void initTriTachMarketsTyle() {
        SectorAPI sector = Global.getSector();
        StarSystemAPI system = sector.getStarSystem("Tyle");
        PlanetAPI aisoyim = system.addPlanet("aisoyim", system.getEntityById("tyle"), "Aisoyimstan", "rocky_ice", 280, 150, 7000, 300);
        aisoyim.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "volturn"));
        aisoyim.applySpecChanges();
        aisoyim.setInteractionImage("illustrations", "cargo_loading");
        aisoyim.setCustomDescriptionId("planet_aisoyim");
    }

    @Override
    public void onNewGame() {
        boolean haveNexerelin = Global.getSettings().getModManager().isModEnabled("nexerelin");
        if (!haveNexerelin || SectorManager.getManager().isCorvusMode()) {
            initDE();
            initTriTachMarketsYma();
            initTriTachMarketsAztlan();
            initTriTachMarketsZagan();
            initTriTachMarketsHybrasil();
            initTriTachMarketsTyle();
        }
    }

    // Some conditions(eg. Large Refugee Population) are not added as the game already adds them as hidden conditions that affect markets without explicitly showing themselves on the intel screen
    private static void initAskonia() {
        SectorAPI sector = Global.getSector();
        StarSystemAPI system = sector.getStarSystem("Askonia");
        SectorEntityToken a1 = system.getEntityById("sindria");
        a1.getMarket().addCondition("DE_Lobsters");
        a1.getMarket().addIndustry(Industries.STARFORTRESS);
        // a1.getMarket().addIndustry(Industries.PLANETARYSHIELD); // Add if you want to suffer
        a1.getMarket().getIndustry(Industries.ORBITALWORKS).setSpecialItem(new SpecialItemData(Items.PRISTINE_NANOFORGE, null));
        a1.getMarket().getIndustry(Industries.HIGHCOMMAND).setSpecialItem(new SpecialItemData(Items.CRYOARITHMETIC_ENGINE, null));

        SectorEntityToken a2 = system.getEntityById("volturn");
        a2.getMarket().addCondition(Conditions.DISSIDENT);
        a2.getMarket().addCondition(Conditions.VICE_DEMAND);
        a2.getMarket().getIndustry(Industries.LIGHTINDUSTRY).setSpecialItem(new SpecialItemData(Items.BIOFACTORY_EMBRYO, null));

        SectorEntityToken a3 = system.getEntityById("cruor");
        a3.getMarket().getIndustry(Industries.MINING).setSpecialItem(new SpecialItemData(Items.MANTLE_BORE, null));
    }

    // Hi im Tri-Tach and I abuse the hell out of colony items
    private static void initHybrasilTTMarketChanges() {
        SectorAPI sector = Global.getSector();
        StarSystemAPI system = sector.getStarSystem("Hybrasil");
        SectorEntityToken h1 = system.getEntityById("culann");
        h1.getMarket().getIndustry(Industries.MILITARYBASE).setSpecialItem(new SpecialItemData(Items.CRYOARITHMETIC_ENGINE, null));
        h1.getMarket().getIndustry(Industries.REFINING).setSpecialItem(new SpecialItemData(Items.CATALYTIC_CORE, null));

        SectorEntityToken h2 = system.getEntityById("eochu_bres");
        h2.getMarket().addIndustry(Industries.HEAVYBATTERIES);
        h2.getMarket().getIndustry(Industries.LIGHTINDUSTRY).setSpecialItem(new SpecialItemData(Items.BIOFACTORY_EMBRYO, null));
        h2.getMarket().getIndustry(Industries.FARMING).setSpecialItem(new SpecialItemData(Items.SOIL_NANITES, null));
    }

    @Override
    public void onNewGameAfterEconomyLoad() {
        boolean haveNexerelin = Global.getSettings().getModManager().isModEnabled("nexerelin");
        if (!haveNexerelin || SectorManager.getManager().isCorvusMode()) {
            initAskonia();
            initHybrasilTTMarketChanges();
        }
    }

}






