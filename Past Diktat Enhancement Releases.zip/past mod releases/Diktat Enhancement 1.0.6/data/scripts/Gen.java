package data.scripts;



import com.fs.starfarer.api.campaign.*;
import data.scripts.world.systems.DE_Andor;
import data.scripts.world.systems.DE_Askonia;
import data.scripts.world.systems.DE_Valhalla;



public class Gen implements SectorGeneratorPlugin {

    @Override
    public void generate(SectorAPI sector) {

        new DE_Andor().generate(sector);
        new DE_Askonia().generate(sector);
        new DE_Valhalla().generate(sector);
    }

}




