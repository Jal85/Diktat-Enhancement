package data.scripts;

import com.fs.starfarer.api.BaseModPlugin;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.*;
import com.fs.starfarer.api.campaign.econ.EconomyAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.impl.campaign.ids.*;

import static com.fs.starfarer.api.impl.campaign.ids.Industries.BATTLESTATION;
import static data.scripts.DEAddMarketplace.addMarketplace;
import com.fs.starfarer.api.impl.campaign.ids.Submarkets;
import data.scripts.Gen;


public class DE_ModPlugin extends BaseModPlugin {
    private static void initDE() {
        new Gen().generate(Global.getSector());
    }

    @Override
    public void onNewGame() {
        initDE();
    }

    // Some conditions(eg. Large Refugee Population) are not added as the game already adds them as hidden conditions that affect markets without explicitly showing themselves on the intel screen
    private static void initAskonia() {
        SectorAPI sector = Global.getSector();
        StarSystemAPI system = sector.getStarSystem("Askonia");
        SectorEntityToken a1 = system.getEntityById("sindria");
        a1.getMarket().addCondition("DE_Lobsters");
        a1.getMarket().addIndustry(Industries.STARFORTRESS);
        // a1.getMarket().addIndustry(Industries.PLANETARYSHIELD); // Add if you want to suffer
        a1.getMarket().getIndustry(Industries.ORBITALWORKS).setSpecialItem(new SpecialItemData(Items.PRISTINE_NANOFORGE, null));
        a1.getMarket().getIndustry(Industries.HIGHCOMMAND).setSpecialItem(new SpecialItemData(Items.CRYOARITHMETIC_ENGINE, null));

        SectorEntityToken a2 = system.getEntityById("volturn");
        a2.getMarket().addCondition(Conditions.DISSIDENT);
        a2.getMarket().addCondition(Conditions.VICE_DEMAND);
        a2.getMarket().getIndustry(Industries.LIGHTINDUSTRY).setSpecialItem(new SpecialItemData(Items.BIOFACTORY_EMBRYO, null));

        SectorEntityToken a3 = system.getEntityById("cruor");
        a3.getMarket().getIndustry(Industries.MINING).setSpecialItem(new SpecialItemData(Items.MANTLE_BORE, null));
    }

    @Override
    public void onNewGameAfterEconomyLoad() {
        initAskonia();
    }

}






