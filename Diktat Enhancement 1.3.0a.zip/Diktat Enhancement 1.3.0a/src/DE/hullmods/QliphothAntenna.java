package DE.hullmods;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import org.lazywizard.lazylib.combat.CombatUtils;

import java.awt.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

// Adapted from Andrada Resonator
public class QliphothAntenna extends BaseHullMod {

	private static final float RANGE = 999999f;
	private static final String id = "qliphothsmall_data";
	public static final Color JITTER_COLOR = new Color(102, 36, 110,255);
	public static final Color JITTER_UNDER_COLOR = new Color(63, 43, 65,255);
	private final HashSet<ShipAPI> affectedships = new HashSet<ShipAPI>();
	private final List<ShipAPI> purgelist = new ArrayList<ShipAPI>();
	public float BASE_DISS = 1f;
	public float BASE_SPEED = 2f;
	public float AMT_SHIPS = 0f;
	public float JITTER_LEVEL = 1f;
	public float UNDER_JITTER_LEVEL = 1f;
	
	public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
	}

	@Override
	public void advanceInCombat(ShipAPI ship, float amount) {
		CombatEngineAPI engine = Global.getCombatEngine();
		List<ShipAPI> shiplist = CombatUtils.getShipsWithinRange(ship.getLocation(), RANGE);

		// add the ship to a list of targets
		for (ShipAPI ship2 : shiplist) {
			if (ship2.getVariant().hasHullMod("qliphothantenna") && ship2.getOwner() == ship.getOwner() && ship2 != ship) {
				//String str4 = String.format("In range: %s, has hull mod %s, same owner %s", MathUtils.isWithinRange(ship2, ship, RANGE), ship2.getVariant().hasHullMod("andrada_mods"), ship2.getOwner() == ship.getOwner());
				//Global.getLogger(this.getClass()).info(str4);
				affectedships.add(ship2);
			}
		}
		// applying effects to targets
		for (ShipAPI target : affectedships) {
			AMT_SHIPS = (float) affectedships.size() / 2;
			JITTER_LEVEL = JITTER_LEVEL + (int) (AMT_SHIPS/2);
			UNDER_JITTER_LEVEL = UNDER_JITTER_LEVEL + (int) (AMT_SHIPS/2);

			// add limits to reduce lag
			if (JITTER_LEVEL > 10) {
				JITTER_LEVEL = 10;
			}
			if (UNDER_JITTER_LEVEL > 15) {
				UNDER_JITTER_LEVEL = 15;
			}
			// MathUtils.getDistance(target.getLocation(), ship.getLocation()) <= RANGE &&
			// check for target aliveness(pokes with stick)
			if (target.isAlive()) {
				// will apply when ship is alive
				target.getMutableStats().getMaxSpeed().modifyFlat(id, (BASE_SPEED * AMT_SHIPS));
				target.getMutableStats().getFluxDissipation().modifyMult(id, BASE_DISS + (0.01f * AMT_SHIPS));
				target.setJitter(target, JITTER_COLOR, (0.01f * AMT_SHIPS), (int) JITTER_LEVEL, 1f, 3f);
				target.setJitterUnder(target, JITTER_UNDER_COLOR, (0.1f * AMT_SHIPS), (int) UNDER_JITTER_LEVEL, 1f, 5f);
			} else {
				// applies when ship is dead
				target.getMutableStats().getMaxSpeed().unmodifyFlat(id);
				target.getMutableStats().getFluxDissipation().unmodify(id);
				purgelist.add(target);
			}
		}
		// clears affected ships list when combat ends
		if (engine.isCombatOver()) {
			affectedships.clear();
		}
		// removes ship from the affected ships list
		for (ShipAPI purge : purgelist) {
			affectedships.remove(purge);
			//purgelist.clear();
		}
	}
	
	public String getDescriptionParam(int index, HullSize hullSize) {
		if (index == 0) return "" + 1 + "%";
		if (index == 1) return "" + 1;
		return null;
	}

	/*public boolean isApplicableToShip(ShipAPI ship) {
		return ship != null && (ship.getHullSpec().getNoCRLossTime() < 10000 || ship.getHullSpec().getCRLossPerSecond(ship.getMutableStats()) > 0); 
	}*/
}
