package DE.hullmods;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.combat.CombatUtils;

import java.awt.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;


public class KorsiaArray extends BaseHullMod {
    // Taken from Andrada Resonator
    private static final float RANGE = 99999f;
    private static final String id = "andradamodulator_data";
    public static final Color JITTER_COLOR = new Color(200,0,120,255);
    public static final Color JITTER_UNDER_COLOR = new Color(140,0,120,255);
    public static Color EMP_FRINGE_COLOR = new Color(218, 177, 177,255);
    private final HashSet<ShipAPI> affectedships = new HashSet<ShipAPI>();
    private final List<ShipAPI> purgelist = new ArrayList<ShipAPI>();
    public static float SUPP_PENALTY = 1.5f;
    public static float SPEED_PENALTY = 20f;
    public static float SHIELD_PENALTY = 20f;
    public static float SPEED_BONUS = 40f;
    public static float ENERGY_FLUX_BONUS = 20f;
    public static float ENERGY_RANGE_BONUS = 30f;

    public void applyEffectsBeforeShipCreation(ShipAPI.HullSize hullSize, MutableShipStatsAPI stats, String id) {
        stats.getSuppliesPerMonth().modifyMult(id, SUPP_PENALTY);
        stats.getMaxSpeed().modifyFlat(id, -SPEED_PENALTY);
        stats.getShieldDamageTakenMult().modifyPercent(id, SHIELD_PENALTY);
    }

    @Override
    public void advanceInCombat(ShipAPI ship, float amount) {
        CombatEngineAPI engine = Global.getCombatEngine();
        List<ShipAPI> shiplist = CombatUtils.getShipsWithinRange(ship.getLocation(), RANGE);

        // add the ship to a list of targets
        for (ShipAPI ship2 : shiplist) {
            if (ship2.getVariant().hasHullMod("andrada_mods") && ship2.getOwner() == ship.getOwner() && ship2 != ship) {
                //String str4 = String.format("In range: %s, has hull mod %s, same owner %s", MathUtils.isWithinRange(ship2, ship, RANGE), ship2.getVariant().hasHullMod("andrada_mods"), ship2.getOwner() == ship.getOwner());
                //Global.getLogger(this.getClass()).info(str4);
                affectedships.add(ship2);
            }
        }
        // applying effects to targets
        for (ShipAPI target : affectedships) {
            // check if our dear target is still truly in range
            if (MathUtils.getDistance(target.getLocation(), ship.getLocation()) <= RANGE && target.isAlive()) {
                // will apply when ship is in range
                target.getMutableStats().getMaxSpeed().modifyFlat(id, SPEED_BONUS);
                target.getMutableStats().getEnergyWeaponFluxCostMod().modifyPercent(id, ENERGY_FLUX_BONUS);
                target.getMutableStats().getEnergyWeaponRangeBonus().modifyPercent(id, ENERGY_RANGE_BONUS);
                //target.setJitter(this, JITTER_COLOR, 0.5f, 1, 0, 0);
                //target.setJitterUnder(this, JITTER_UNDER_COLOR, 0.5f, 3, 0f, 0);
                target.addAfterimage(JITTER_COLOR, target.getLocation().x,target.getLocation().y, target.getVelocity().x, target.getVelocity().y,1f, 0.1f, 1f, 3f, false, true, false);
            } else {
                // he's not! rattle em code!
                // applies when ship is out of range
                target.getMutableStats().getMaxSpeed().unmodifyFlat(id);
                target.getMutableStats().getEnergyWeaponFluxCostMod().unmodify(id);
                target.getMutableStats().getEnergyWeaponRangeBonus().unmodify(id);
                purgelist.add(target);
            }
        }
        // clears affected ships list when combat ends
        if (engine.isCombatOver()) {
            affectedships.clear();
        }
        // removes ship from the affected ships list
        for (ShipAPI purge : purgelist) {
            affectedships.remove(purge);
            //purgelist.clear();
        }
    }

    public String getDescriptionParam(int index, ShipAPI.HullSize hullSize) {
        if (index == 0) return "infinite";

        return null;
    }

    public void addPostDescriptionSection(TooltipMakerAPI tooltip, ShipAPI.HullSize hullSize, ShipAPI ship, float width, boolean isForModSpec) {
        float pad = 3f;
        float opad = 10f;
        Color h = Misc.getHighlightColor();
        Color bad = Misc.getNegativeHighlightColor();

        tooltip.addPara("Increases ally max speed by %s units, "
                        + "decreases energy weapon flux by %s, "
                        + "and increases energy weapon range by %s. ",
                opad, h,
                "" + (int) SPEED_BONUS,
                "" + (int) (ENERGY_FLUX_BONUS) + "%",
                "" + (int) (ENERGY_RANGE_BONUS) + "%"
        );

        tooltip.addPara("Supplies per month increased by %s, "
                        + "max speed decreased by %s units, "
                        + "and shield efficiency reduced by %s. ",
                opad, bad,
                "" + (int) ((SUPP_PENALTY - 1f) * 100f) + "%",
                "" + (int) (SPEED_PENALTY),
                "" + (int) (SHIELD_PENALTY) + "%"
        );
    }
}






