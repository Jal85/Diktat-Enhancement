package DE.hullmods;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.combat.CombatUtils;
import org.lwjgl.util.vector.Vector2f;
import org.magiclib.util.MagicRender;

import java.awt.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;


public class AndradaResonator extends BaseHullMod {
    // Thanks for Nia's Adlerauge effect script for parts of this
    private static final float RANGE = 1000f;
    private static boolean spawnedring = false;
    private static final String id = "andradamodulator_data";
    public static final Color JITTER_COLOR = new Color(200,0,120,255);
    public static final Color JITTER_UNDER_COLOR = new Color(140,0,120,255);
    public static Color EMP_FRINGE_COLOR = new Color(218, 177, 177,255);
    private final HashSet<ShipAPI> affectedships = new HashSet<ShipAPI>();
    private final List<ShipAPI> purgelist = new ArrayList<ShipAPI>();
    public static float SPEED_BONUS = 10f;
    public static float MANEUVERIBILITY_BONUS = 20f;
    public static float ENERGY_FLUX_BONUS = 10f;
    public static float ENERGY_RANGE_BONUS = 10f;
    public static float ENERGY_ROF_BONUS = 10f;
    public static float TIME_MULT_BONUS = 5f;
    
    @Override
    public void advanceInCombat(ShipAPI ship, float amount) {
        CombatEngineAPI engine = Global.getCombatEngine();
        List<ShipAPI> shiplist = CombatUtils.getShipsWithinRange(ship.getLocation(), RANGE);

        if (ship.isAlive()) {
            MagicRender.objectspace(
                    // this needs to be loaded in settings.json, and then you can just stick in the file path
                    Global.getSettings().getSprite("sprites", "drive_circle"),
                    // what the ring will be centered on. In this case, the ship using the system. what "ship" means
                    // was determined in the second part of this public void thingamajig.
                    ship,
                    new Vector2f(),
                    new Vector2f(),
                    // the radius of the circle will be about half this
                    new Vector2f(2000, 2000),
                    new Vector2f(),
                    0,
                    120,
                    // set to true to make the ring turn with the ship
                    true,
                    // the color, obviously. I don't think the alpha value really works, instead I'm using a
                    // very transparent sprite
                    new Color(200, 0, 120, 75),
                    true,
                    0.1f,
                    0f,
                    0.1f,
                    true
            );
        }

        // add the ship to a list of targets
        for (ShipAPI ship2 : shiplist) {
            if (ship2.getVariant().hasHullMod("andrada_mods") && ship2.getOwner() == ship.getOwner() && ship2 != ship) {
                //String str4 = String.format("In range: %s, has hull mod %s, same owner %s", MathUtils.isWithinRange(ship2, ship, RANGE), ship2.getVariant().hasHullMod("andrada_mods"), ship2.getOwner() == ship.getOwner());
                //Global.getLogger(this.getClass()).info(str4);
                affectedships.add(ship2);
            }
        }
        // applying effects to targets
        for (ShipAPI target : affectedships) {
            // check if our dear target is still truly in range
            if (MathUtils.getDistance(target.getLocation(), ship.getLocation()) <= RANGE && target.isAlive()) {
                // will apply when ship is in range
                target.getMutableStats().getMaxSpeed().modifyFlat(id, SPEED_BONUS);
                target.getMutableStats().getAcceleration().modifyPercent(id, MANEUVERIBILITY_BONUS);
                target.getMutableStats().getDeceleration().modifyPercent(id, MANEUVERIBILITY_BONUS);
                target.getMutableStats().getEnergyWeaponFluxCostMod().modifyPercent(id, ENERGY_FLUX_BONUS);
                target.getMutableStats().getEnergyWeaponRangeBonus().modifyPercent(id, ENERGY_RANGE_BONUS);
                target.getMutableStats().getEnergyRoFMult().modifyPercent(id, ENERGY_ROF_BONUS);
                target.getMutableStats().getTimeMult().modifyPercent(id, TIME_MULT_BONUS);
                target.setJitter(this, JITTER_COLOR, 0.5f, 1, 0, 0);
                target.setJitterUnder(this, JITTER_UNDER_COLOR, 0.5f, 3, 0f, 0);
            } else {
                // he's not! rattle em code!
                // applies when ship is out of range
                target.getMutableStats().getMaxSpeed().unmodifyFlat(id);
                target.getMutableStats().getAcceleration().unmodify(id);
                target.getMutableStats().getDeceleration().unmodify(id);
                target.getMutableStats().getEnergyWeaponFluxCostMod().unmodify(id);
                target.getMutableStats().getEnergyWeaponRangeBonus().unmodify(id);
                target.getMutableStats().getEnergyRoFMult().unmodify(id);
                target.getMutableStats().getTimeMult().unmodify(id);
                purgelist.add(target);
            }
        }
        // clears affected ships list when combat ends
        if (engine.isCombatOver()) {
            affectedships.clear();
            spawnedring = false;
        }
        // removes ship from the affected ships list
        for (ShipAPI purge : purgelist) {
            affectedships.remove(purge);
            //purgelist.clear();
        }
    }

    public String getDescriptionParam(int index, ShipAPI.HullSize hullSize) {
        if (index == 0) return "" + RANGE;

        return null;
    }

    public void addPostDescriptionSection(TooltipMakerAPI tooltip, ShipAPI.HullSize hullSize, ShipAPI ship, float width, boolean isForModSpec) {
        float pad = 3f;
        float opad = 10f;
        Color h = Misc.getHighlightColor();
        Color bad = Misc.getNegativeHighlightColor();

        tooltip.addPara("Increases ally max speed by %s units, "
                        + "maneuverability by %s, "
                        + "decreases energy weapon flux by %s, "
                        + "increases energy weapon range by %s, "
                        + "increases energy rate of fire by %s, "
                        + "and increase timeflow by %s. ",
                opad, h,
                "" + (int) SPEED_BONUS,
                "" + (int) (MANEUVERIBILITY_BONUS) + "%",
                "" + (int) (ENERGY_FLUX_BONUS) + "%",
                "" + (int) (ENERGY_RANGE_BONUS) + "%",
                "" + (int) (ENERGY_ROF_BONUS) + "%",
                "" + (int) (TIME_MULT_BONUS) + "%"
        );
    }
}






