package DE.combat.ai;

import DE.combat.VectorManipulatorStats;
import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.util.IntervalUtil;
import org.lazywizard.lazylib.combat.AIUtils;
import org.lwjgl.util.vector.Vector2f;

import java.util.ArrayList;
import java.util.List;


public class VectorManipulatorAI implements ShipSystemAIScript {

	public static float HULL_LOSS_FOR_ACTIVATION = 0.25f;
	
	protected ShipAPI ship;
	protected CombatEngineAPI engine;
	protected ShipwideAIFlags flags;
	protected ShipSystemAPI system;
	protected VectorManipulatorStats script;
	
	protected IntervalUtil tracker = new IntervalUtil(0.75f, 1.25f);

	protected List<WeaponAPI> weapons;
	protected List<WeaponAPI> checked;
	protected ShipAPI nearestenemy;

	protected float range;
	
	public void init(ShipAPI ship, ShipSystemAPI system, ShipwideAIFlags flags, CombatEngineAPI engine) {
		this.ship = ship;
		this.flags = flags;
		this.engine = engine;
		this.system = system;

		this.checked = new ArrayList<WeaponAPI>();

		script = (VectorManipulatorStats)system.getScript();
	}
	
	public void advance(float amount, Vector2f missileDangerDir, Vector2f collisionDangerDir, ShipAPI target) {
		if (ship == null) return;

        weapons = ship.getAllWeapons();

		if (!weapons.isEmpty()) {
			// get the range of weapon 1 and add it into checked list
			range = weapons.get(1).getRange() / 2f;
			checked.add(weapons.get(1));

			for (WeaponAPI weapon : weapons) {
				if (!checked.contains(weapon)) {
					// compare the ranges of subsequent weapons. If it's higher, replace range with that, otherwise retry
					if (weapon.getRange() / 2f >= range) {
						range = weapon.getRange() / 2f;
						checked.add(weapon);
					} else {
						checked.add(weapon);
					}
				}
			}
		}

		if(engine.isPaused()){
			return;
		}

		nearestenemy = AIUtils.getNearestEnemy(ship);
		if (nearestenemy == null) {
			return;
		}

		tracker.advance(amount);

		if (tracker.intervalElapsed()) {
			// when ship is in range of gimped weapons range, trigger
			if (!AIUtils.getNearbyEnemies(ship, range).isEmpty()) {
				ship.giveCommand(ShipCommand.USE_SYSTEM, null, 0);
				// force-set nearest enemy as target and pursue them
				ship.setShipTarget(nearestenemy);
				ship.getAIFlags().setFlag(ShipwideAIFlags.AIFlags.PURSUING);
				// this stupid thing below doesn't work
				//ship.useSystem();
			}
			tracker.nextInterval();
		}
	}
	
	/*public void giveCommand(Vector2f target) {
		if (ship.getAIFlags() != null) {
			ship.getAIFlags().setFlag(AIFlags.SYSTEM_TARGET_COORDS, 1f, target);
		}
		ship.giveCommand(ShipCommand.USE_SYSTEM, null, 0);
	}*/

}






















