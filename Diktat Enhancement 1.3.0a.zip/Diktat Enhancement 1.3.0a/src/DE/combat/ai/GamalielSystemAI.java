package DE.combat.ai;

import DE.combat.GamalielSystemStats;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.combat.ShipwideAIFlags.AIFlags;
import com.fs.starfarer.api.util.IntervalUtil;
import org.lazywizard.lazylib.combat.AIUtils;
import org.lwjgl.util.vector.Vector2f;


public class GamalielSystemAI implements ShipSystemAIScript {

	public static float HULL_LOSS_FOR_ACTIVATION = 0.25f;

	protected ShipAPI ship;
	protected CombatEngineAPI engine;
	protected ShipwideAIFlags flags;
	protected ShipSystemAPI system;
	protected GamalielSystemStats script;

	protected IntervalUtil tracker = new IntervalUtil(0.75f, 1.25f);
	protected IntervalUtil tracker2 = new IntervalUtil(15f, 15f);

	protected float hullLevelAtPrevSystemUse = 1f;
	protected float prevHardFluxLevel = 0f;

	public void init(ShipAPI ship, ShipSystemAPI system, ShipwideAIFlags flags, CombatEngineAPI engine) {
		this.ship = ship;
		this.flags = flags;
		this.engine = engine;
		this.system = system;

		script = (GamalielSystemStats) system.getScript();
	}

	public void advance(float amount, Vector2f missileDangerDir, Vector2f collisionDangerDir, ShipAPI target) {
		if (ship == null) return;

		if (engine.isPaused()) {
			return;
		}

		tracker.advance(amount);
		tracker2.advance(amount);

		if (tracker.intervalElapsed()) {
			Global.getLogger(GamalielSystemAI.class).info("proccing interval, at least");
			// defensive use of shipsystem(dive when shit gets bad)
			if (ship.getFluxLevel() > 0.95f || ship.getAIFlags().hasFlag(AIFlags.IN_CRITICAL_DPS_DANGER)) {
				//ship.useSystem();
				ship.giveCommand(ShipCommand.USE_SYSTEM, null, 0);
				Global.getLogger(GamalielSystemAI.class).info("proccing defensive");
			}

			// offensive use of shipsystem(attack enemies or proc uses)
			if (!AIUtils.getNearbyEnemies(ship, 1500).isEmpty() || ship.getAIFlags().hasFlag(AIFlags.PURSUING)) {
				//ship.useSystem();
				ship.giveCommand(ShipCommand.USE_SYSTEM, null, 0);
				Global.getLogger(GamalielSystemAI.class).info("proccing offensive");
			}
			tracker.nextInterval();
		}

		// to force-proc uses to get benefits
		if (tracker2.intervalElapsed()) {
			if (AIUtils.canUseSystemThisFrame(ship)) {
				//ship.useSystem();
				ship.giveCommand(ShipCommand.USE_SYSTEM, null, 0);
				Global.getLogger(GamalielSystemAI.class).info("proccing ramp");
			}
			tracker2.nextInterval();
		}

		/*boolean forceUse = false;
		if (ship.getFluxLevel() > 0.95f && ship.getHullLevel() > 0.25f && 
				ship.getShield() != null && ship.getShield().isOn()) {
			forceUse = true;
		}
		
		if (tracker.intervalElapsed() || forceUse) {
			if (system.getCooldownRemaining() > 0) return;
			if (system.isOutOfAmmo()) return;
			if (system.isActive()) return;
			if (ship.getFluxTracker().isOverloadedOrVenting()) return;
			
			float hullLevel = ship.getHullLevel();
			float hardFluxLevel = ship.getHardFluxLevel();
			float fluxLevel = ship.getFluxLevel();
			
			boolean useSystem = hullLevel <= hullLevelAtPrevSystemUse - HULL_LOSS_FOR_ACTIVATION;
			
			if (((hardFluxLevel >= prevHardFluxLevel && hardFluxLevel >= 0.33f) || fluxLevel > 0.65f) &&
					ship.getAIFlags().hasFlag(AIFlags.BACKING_OFF)) {// && (float) Math.random() > 0.75f) {
				if (target != null) {
					float dist = Misc.getDistance(ship.getLocation(), target.getLocation());
					dist -= ship.getCollisionRadius() + target.getCollisionRadius();
					if (dist < 1000f || hardFluxLevel > prevHardFluxLevel + 0.02f) {
						useSystem = true;
					}
				}
			}
			
			prevHardFluxLevel = hardFluxLevel;
			
			useSystem |= forceUse;
			
			if (useSystem) {
				float angle = ship.getFacing();
				if (target != null) {
					angle = Misc.getAngleInDegrees(ship.getLocation(), target.getLocation());
				}
				if (missileDangerDir != null) {
					float angle2 = Misc.getAngleInDegrees(missileDangerDir);
					if (target != null) {
						angle = angle + Misc.getClosestTurnDirection(angle, angle2) * 0.5f * Misc.getAngleDiff(angle, angle2);
					} else {
						angle = angle2;
					}
				}
				
				Vector2f point = Misc.getUnitVectorAtDegreeAngle(angle);
				point.scale(2000f);
				Vector2f.add(point, ship.getLocation(), point);
				
				giveCommand(point);
				hullLevelAtPrevSystemUse = hullLevel;
				return;
			}
		}
	}
	
	public void giveCommand(Vector2f target) {
		if (ship.getAIFlags() != null) {
			ship.getAIFlags().setFlag(AIFlags.SYSTEM_TARGET_COORDS, 1f, target);
		}
		ship.giveCommand(ShipCommand.USE_SYSTEM, null, 0);
	}*/

	}
}






















