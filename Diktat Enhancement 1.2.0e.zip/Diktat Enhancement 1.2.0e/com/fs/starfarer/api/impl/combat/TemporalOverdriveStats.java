package com.fs.starfarer.api.impl.combat;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.SoundAPI;
import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.util.IntervalUtil;
import java.awt.Color;

import org.lazywizard.lazylib.MathUtils;
import com.fs.starfarer.api.combat.ShipAPI;
import org.lwjgl.util.vector.Vector2f;

public class TemporalOverdriveStats extends BaseShipSystemScript {
    //Code Courtesy of the Titan code from Interstellar Imperium by Dark Revenant, and the Crusher Drive System from Tahlan by Nia and maybe Tart
    //Parts of code Courtesy of Luddic Enhancement by Alfonzo


    public static final float MAX_TIME_MULT = 5f;
    public static final float MIN_TIME_MULT = 0.1f;
    public static final float DAM_MULT = 0.1f;

    public static final Color JITTER_COLOR = new Color(90,165,255,55);
    public static final Color JITTER_UNDER_COLOR = new Color(90,165,255,155);

    public static final float SPEED_BOOST = 180f;

    private boolean exploded = false;
    private final IntervalUtil interval = new IntervalUtil(0.2f, 0.2f);
    private final IntervalUtil interval2 = new IntervalUtil(10f, 10f);
    private SoundAPI sound = null;
    private boolean started = false;

    @Override
    public void apply(MutableShipStatsAPI stats, String id, State state, float effectLevel) {

        CombatEngineAPI engine = Global.getCombatEngine();
        ShipAPI ship = (ShipAPI) stats.getEntity();
        boolean player = false;
        if (stats.getEntity() instanceof ShipAPI) {
            ship = (ShipAPI) stats.getEntity();
            player = ship == Global.getCombatEngine().getPlayerShip();
            id = id + "_" + ship.getId();
        } else {
            return;
        }
        
        float jitterLevel = effectLevel;
        float jitterRangeBonus = 0;
        float maxRangeBonus = 10f;
        if (state == State.IN) {
            jitterLevel = effectLevel / (1f / ship.getSystem().getChargeUpDur());
            if (jitterLevel > 1) {
                jitterLevel = 1f;
            }
            jitterRangeBonus = jitterLevel * maxRangeBonus;
        } else if (state == State.ACTIVE) {
            jitterLevel = 1f;
            jitterRangeBonus = maxRangeBonus;
        } else if (state == State.OUT) {
            jitterRangeBonus = jitterLevel * maxRangeBonus;
        }
        jitterLevel = (float) Math.sqrt(jitterLevel);
        effectLevel *= effectLevel;

        ship.setJitter(this, JITTER_COLOR, jitterLevel, 3, 0, 0 + jitterRangeBonus);
        ship.setJitterUnder(this, JITTER_UNDER_COLOR, jitterLevel, 25, 0f, 7f + jitterRangeBonus);

        /*IntervalUtil interval3 = new IntervalUtil(0.25f,0.25f);

        @Override
        public void advanceInCombat(ShipAPI ship, float amount) {

            if (!ship.isAlive()) return;

            CombatEngineAPI engine = Global.getCombatEngine();

            interval3.advance(amount);
            if (interval3.intervalElapsed()) {
                for (WeaponAPI w : ship.getAllWeapons()) {
                    if (w.usesAmmo() && w.getAmmo() < w.getMaxAmmo()) {
                        w.setAmmo(w.getAmmo() + 1);
                    }
                }
            }
        }*/

        IntervalUtil interval3 = new IntervalUtil(0.05f,0.05f);

            if (!ship.isAlive()) return;

            interval3.advance(Global.getCombatEngine().getElapsedInLastFrame());
            if (interval3.intervalElapsed()) {
                for (WeaponAPI w : ship.getAllWeapons()) {
                    if (w.usesAmmo() && w.getAmmo() < w.getMaxAmmo()) {
                        w.setAmmo(w.getAmmo() + 1);
                    }
                }
            }

        float shipTimeMult = 1f + (MAX_TIME_MULT - 1f) * effectLevel;
        stats.getTimeMult().modifyMult(id, shipTimeMult);

        if (player) {
            Global.getCombatEngine().getTimeMult().modifyMult(id, 1f / shipTimeMult);
//			if (ship.areAnyEnemiesInRange()) {
//				Global.getCombatEngine().getTimeMult().modifyMult(id, 1f / shipTimeMult);
//			} else {
//				Global.getCombatEngine().getTimeMult().modifyMult(id, 2f / shipTimeMult);
//			}
        } else {
            Global.getCombatEngine().getTimeMult().unmodify(id);
        }

        ship.getEngineController().fadeToOtherColor(this, JITTER_COLOR, new Color(0,0,0,0), effectLevel, 0.5f);
        ship.getEngineController().extendFlame(this, -0.25f, -0.25f, -0.25f);

        if (ship == null) {
            return;
        }

        if (Global.getCombatEngine().isPaused()) {
            return;
        }

        ShipAPI target = ship.getShipTarget();
        float turnrate = ship.getMaxTurnRate()*2;

        //       if(target!=null && ship.getSystem().isActive()){
        //system's aiming effect
//            float facing = ship.getFacing();
//            facing=MathUtils.getShortestRotation(
//                    facing,
//                    VectorUtils.getAngle(ship.getLocation(), target.getLocation())
//            );
//            ship.setAngularVelocity(Math.min(turnrate, Math.max(-turnrate, facing*5)));
//        }

        interval.advance(Global.getCombatEngine().getElapsedInLastFrame());
        ship.setJitter(stats.getEntity(), JITTER_COLOR, effectLevel, 5 + Math.round(effectLevel * 5f), effectLevel * 5f, 10f + (effectLevel * 20f));

        //CombatEntityAPI entity = stats.getEntity();
        Vector2f point = new Vector2f(ship.getLocation());
        point.x += ship.getCollisionRadius() * (((float) Math.random() * 2f) - 1f);
        point.y += ship.getCollisionRadius() * (((float) Math.random() * 2f) - 1f);
        //TemporalOverdrivePlugin.explode(ship, 1f);
        interval2.setInterval(10f, 10f);
        interval2.advance(engine.getElapsedInLastFrame());
        //interval2.intervalElapsed()
        if (state == State.OUT) {
            engine.applyDamage(
                    ship,
                    point,
                    Float.MAX_VALUE,
                    DamageType.HIGH_EXPLOSIVE,
                    0f,
                    true,
                    false,
                    ship);
            engine.spawnExplosion(ship.getLocation(), ship.getVelocity(), Color.WHITE, 100f, 10f);
        }

        if (!started) {
            started = true;

            float distanceToHead = MathUtils.getDistance(stats.getEntity(),
                    Global.getCombatEngine().getViewport().getCenter());
            float refDist = 1500f;
            float vol = refDist / Math.max(refDist, distanceToHead);
            //sound = Global.getSoundPlayer().playUISound("le_might_explode_charge", 1f, vol);
        }

//        if ((state == State.IN && !exploded)) {
//           stats.getMaxSpeed().modifyFlat(id, SPEED_BOOST);
//            stats.getAcceleration().modifyFlat(id, SPEED_BOOST * 3);
//
//            if(target!=null && ship.getSystem().isActive()) {
//                //system's aiming effect
//                float facing = ship.getFacing();
//                facing = MathUtils.getShortestRotation(
//                        facing,
//                        VectorUtils.getAngle(ship.getLocation(), target.getLocation())
//                );
//                ship.setAngularVelocity(Math.min(turnrate, Math.max(-turnrate, facing * 5)));
//            }
//
//            if (interval.intervalElapsed() && ((Math.random() * Math.random()) > (stats.getEntity().getHullLevel() * 2f))) {
//                if (sound != null) {
//                    sound.stop();
//                }
//                exploded = true;
//                {
//                    LE_Dram_Missile_Plugin.explode(ship, effectLevel);
//                }
//            }
//        }

        /*if ((state == State.ACTIVE) && !exploded) {
            exploded = true;
            {
                //TemporalOverdrivePlugin.explode(ship, 1f);
                engine.applyDamage(ship,
                        point,
                        100000f,
                        DamageType.HIGH_EXPLOSIVE,
                        0f,
                        true,
                        false,
                        ship);
                engine.spawnExplosion(ship.getLocation(), ship.getVelocity(), Color.WHITE, 100f, 10f);
            }
        } else {
            stats.getMaxSpeed().modifyFlat(id, SPEED_BOOST);
            stats.getAcceleration().modifyFlat(id, SPEED_BOOST * 5);

            if(target!=null && ship.getSystem().isActive()) {
                //system's aiming effect
                float facing = ship.getFacing();
                facing = MathUtils.getShortestRotation(
                        facing,
                        VectorUtils.getAngle(ship.getLocation(), target.getLocation())
                );
                ship.setAngularVelocity(Math.min(turnrate, Math.max(-turnrate, facing * 5)));
            }

            if (interval.intervalElapsed() && ((Math.random() * Math.random()) > (stats.getEntity().getHullLevel() * 2f))) {
                if (sound != null) {
                    sound.stop();
                }
                exploded = true;
                {
                    //TemporalOverdrivePlugin.explode(ship, effectLevel);
                    engine.applyDamage(ship,
                            ship.getLocation(),
                            100000f,
                            DamageType.HIGH_EXPLOSIVE,
                            0f,
                            true,
                            false,
                            ship);
                    engine.spawnExplosion(ship.getLocation(), ship.getVelocity(), Color.WHITE, 100f, 10f);
                }
            }
        }*/
    }

    @Override
    public StatusData getStatusData(int index, State state, float effectLevel) {
        if (index == 0) {
            return new StatusData("Time flow altered greatly", false);
        }
        if (index == 1) {
            return new StatusData("Weapon banks supercharged", false);
        }
        if (index == 2) {
            return new StatusData("Temporal stresses will destroy the ship in 10 seconds", true);
        }
        return null;
    }

    @Override
    public void unapply(MutableShipStatsAPI stats, String id) {
        ShipAPI ship = null;
        boolean player = false;
        if (stats.getEntity() instanceof ShipAPI) {
            ship = (ShipAPI) stats.getEntity();
            player = ship == Global.getCombatEngine().getPlayerShip();
            id = id + "_" + ship.getId();
        } else {
            return;
        }

        Global.getCombatEngine().getTimeMult().unmodify(id);
        stats.getTimeMult().unmodify(id);

//		stats.getHullDamageTakenMult().unmodify(id);
//		stats.getArmorDamageTakenMult().unmodify(id);
//		stats.getEmpDamageTakenMult().unmodify(id);
    }
    protected ShipAPI findTarget(ShipAPI ship) {
        ShipAPI target = ship.getShipTarget();
        if(
                target!=null
                        &&
                        (!target.isDrone()||!target.isFighter())
                        &&
                        MathUtils.isWithinRange(ship, target, 2500f)
                        &&
                        target.getOwner()!=ship.getOwner()
        ){
            return target;
        } else {
            return null;
        }
    }

    @Override
    public boolean isUsable(ShipSystemAPI system, ShipAPI ship) {
        ShipAPI target = findTarget(ship);
        return target != null && target != ship;
    }

}
