// 
// Decompiled by Procyon v0.5.36
// 

package DE.combat.weapons;

import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.combat.listeners.ApplyDamageResultAPI;
import com.fs.starfarer.api.loading.ProjectileSpecAPI;
import com.fs.starfarer.api.loading.ProjectileWeaponSpecAPI;
import org.lwjgl.util.vector.Vector2f;

import java.awt.*;

import static com.fs.starfarer.api.combat.DamageType.ENERGY;

public class LuxoblastOnHitEffect implements OnHitEffectPlugin
{
   private static final float EXTRA_DAMAGE_OTHERS = 0;
   private static final float EXTRA_DAMAGE_FRIGATES = 1f;
   private static final float EXTRA_DAMAGE_DESTROYERS = 0.5f;
   private static final float EXTRA_DAMAGE_CAPITALS = -0.5f;
    public static final Color projcolor = new Color(152, 220, 59,255);

    @Override
    public void onHit(DamagingProjectileAPI projectile, CombatEntityAPI target, Vector2f point, boolean shieldHit, ApplyDamageResultAPI damageResult, CombatEngineAPI engine) {
        float damage = projectile.getDamageAmount();
        if ((target instanceof ShipAPI && ((ShipAPI)target).isFrigate())){
            engine.applyDamage(target, point, damage * EXTRA_DAMAGE_FRIGATES, ENERGY, 0f, false, false, projectile.getSource());
        } else if ((target instanceof ShipAPI && ((ShipAPI)target).isDestroyer())) {
            engine.applyDamage (target, point, damage * EXTRA_DAMAGE_DESTROYERS, ENERGY, 0f, false, false, projectile.getSource());
        } else if ((target instanceof ShipAPI && ((ShipAPI)target).isCapital())) {
            engine.applyDamage (target, point, damage * EXTRA_DAMAGE_CAPITALS, ENERGY, 0f, false, false, projectile.getSource());
        }
    }
}
