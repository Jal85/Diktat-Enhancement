package DE.combat;

import com.fs.graphics.anim.SpriteAnimation;
import com.fs.starfarer.api.SettingsAPI;
import com.fs.starfarer.api.SpriteId;
import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.impl.combat.NegativeExplosionVisual;
import com.fs.starfarer.api.impl.combat.RiftCascadeEffect;
import com.fs.starfarer.api.impl.combat.RiftTrailEffect;
import com.fs.starfarer.api.loading.MissileSpecAPI;
import com.fs.starfarer.api.util.IntervalUtil;
import com.fs.starfarer.api.util.JitterUtil;
import org.lwjgl.util.vector.Vector2f;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.ShipwideAIFlags.AIFlags;
import com.fs.starfarer.api.impl.combat.BaseShipSystemScript;
import com.fs.starfarer.api.impl.combat.dweller.VortexLauncherEffect.DisturbShroudPlugin;
import com.fs.starfarer.api.impl.combat.dweller.DwellerShroud;
import com.fs.starfarer.api.util.Misc;

import org.magiclib.util.MagicRender;
import com.fs.starfarer.api.graphics.SpriteAPI;
import com.fs.starfarer.api.SettingsAPI;

import java.awt.*;

public class GamalielSystemStats extends BaseShipSystemScript {

	public static String OBSCENE_WING = "de_gamalielcopy_wing";
	
	public static float REFIRE_DELAY = 0.15f;
	public static float LAUNCH_ARC = 90f;
	public static float BACK_OFF_ACCEL = 500f;
	
	protected Vector2f fireDir;
	protected float elapsedActive = REFIRE_DELAY;
	protected int amtGamsBirthed = 0;
	protected int maxGams = 4;
	protected int systemState = 0;
	// 0 = in phase and untargetable
	// 1 = exit phase, get rof buffs
	// 2 = remove buffs, return to normal state
	protected int systemActivations = 0;

	boolean startTimer = false;
	boolean checkswitch = false;
	boolean checkswitch2 = false;
	boolean trailspawned = false;
	public IntervalUtil interval = new IntervalUtil(10f, 10f);
	public IntervalUtil interval2 = new IntervalUtil(5f, 5f);
	//public static IntervalUtil decaytick = new IntervalUtil(20f, 20f);

	public static final Color JITTER_COLOR = new Color(120, 65, 90, 255);
	public static final Color JITTER_UNDER_COLOR = new Color(99, 48, 121, 255);
	public static final Color FULL_COLOR = new Color(79, 38, 208,255);
	
	protected void init(ShipAPI ship) {
	}

	@Override
	public void apply(MutableShipStatsAPI stats, String id, State state, float effectLevel) {
		ShipAPI ship = null;
		if (stats.getEntity() instanceof ShipAPI) {
			ship = (ShipAPI) stats.getEntity();
		} else {
			return;
		}

		// force max cap of 10
		if (systemActivations > 10) {
			systemActivations = 10;
		}

		//if (startTimer) {
		//	decaytick.advance(Global.getCombatEngine().getElapsedInLastFrame());
		//}

		if (state == State.IN) {
			if (fireDir == null) {
				float dir = ship.getFacing();
				if (ship.getMouseTarget() != null) {
					dir = Misc.getAngleInDegrees(ship.getLocation(), ship.getMouseTarget());
				}
				if (ship.getShipAI() != null && ship.getAIFlags().hasFlag(AIFlags.SYSTEM_TARGET_COORDS)){
					dir = Misc.getAngleInDegrees(ship.getLocation(), 
							(Vector2f) ship.getAIFlags().getCustom(AIFlags.SYSTEM_TARGET_COORDS));
				}
				fireDir = Misc.getUnitVectorAtDegreeAngle(dir);
			}
			checkswitch = false;
			checkswitch2 = false;
		}

		
		if (state == State.ACTIVE && fireDir != null) {
			float amount = Global.getCombatEngine().getElapsedInLastFrame();
			elapsedActive += amount;

			// i hate intervals so fucking much bro
			interval.advance(Global.getCombatEngine().getElapsedInLastFrame());
			if (interval.intervalElapsed()) {
				systemState = 1;
			}
			if (systemState == 1) {
				interval2.advance(Global.getCombatEngine().getElapsedInLastFrame());
			}
			if (interval2.intervalElapsed()) {
				systemState = 2;
			}

			while (elapsedActive >= REFIRE_DELAY) {

				// visuals
				// phase glow method repeated to prevent flickering
				// it did not prevent flickering :(
				// flickering implied to be issue with time mult, annoying
				// was fixed using objectspace renders
				if (systemState == 0) {
					ship.setJitter(stats.getEntity(), JITTER_COLOR, 1, 5, 5f, 10f);
					ship.setJitter(stats.getEntity(), JITTER_UNDER_COLOR, 0.5f, 3, 3f, 15f);
					ship.fadeToColor(ship, JITTER_COLOR, 1f, 1f, 1f);

					//NegativeExplosionVisual.NEParams p = createStandardRiftParams("gamaliel_censor", 25f);
					//p.fadeOut = 2f;
					//p.hitGlowSizeMult = 0.5f;
					spawnStandardRift(ship);
					spawnPhaseGlow(ship);
					spawnPhaseTrail(ship);
					spawnPhaseTrail(ship);
					spawnPhaseTrail(ship);
					//Global.getCombatEngine().addLayeredRenderingPlugin(new NegativeExplosionVisual(createStandardRiftParams(color, 25f)));
				}

				elapsedActive -= REFIRE_DELAY;
				if (amtGamsBirthed < maxGams) {
					fireShroudedEjecta(ship, fireDir);
					amtGamsBirthed += 1;
					startTimer = true;
				}
				ship.setPhased(true);
				if (ship == Global.getCombatEngine().getPlayerShip()) {
					Global.getCombatEngine().getTimeMult().modifyMult(id, 0.33f);
//			if (ship.areAnyEnemiesInRange()) {
//				Global.getCombatEngine().getTimeMult().modifyMult(id, 1f / shipTimeMult);
//			} else {
//				Global.getCombatEngine().getTimeMult().modifyMult(id, 2f / shipTimeMult);
//			}
				} else {
					Global.getCombatEngine().getTimeMult().unmodify(id);
				}
				ship.setBeingIgnored(true);
				ship.setHoldFire(true);
				//Global.getLogger(GamalielSystemStats.class).info("passed initial check");
				ship.getMutableStats().getTimeMult().modifyMult(id, 3f);

				RiftTrailEffect trail = new RiftTrailEffect(ship, "gamaliel_loop");

				if (!trailspawned) {
					Global.getCombatEngine().addPlugin(trail);
					Global.getCombatEngine().addPlugin(trail);
					Global.getCombatEngine().addPlugin(trail);
					trailspawned = true;
				}
				// pweaaaase remove evil trail
				if (interval.intervalElapsed()) {
					Global.getCombatEngine().removePlugin(trail);
					Global.getCombatEngine().removePlugin(trail);
					Global.getCombatEngine().removePlugin(trail);
				}

				if (systemState >= 1) {
					//Global.getLogger(GamalielSystemStats.class).info("passed interval 1");
					ship.setPhased(false);
					ship.setBeingIgnored(false);
					ship.setHoldFire(false);
					ship.getMutableStats().getTimeMult().unmodify();
					Global.getCombatEngine().getTimeMult().unmodify(id);
					// stops game from constantly spamming message
					if (!checkswitch2) {
						ship.getFluxTracker().showOverloadFloatyIfNeeded("Emergence!", JITTER_COLOR, 4f, false);
						checkswitch2 = true;
					}
					// jank method to ensure CR doesn't get excessively drained by phase
					ship.getMutableStats().getPeakCRDuration().modifyFlat(id, 20f);
					// post-phase goodies
					ship.getMutableStats().getBallisticRoFMult().modifyMult(id, 1.5f);
					ship.getMutableStats().getEnergyRoFMult().modifyMult(id, 1.5f);
					ship.getMutableStats().getBallisticWeaponDamageMult().modifyMult(id, 1.5f);
					ship.getMutableStats().getEnergyWeaponDamageMult().modifyMult(id, 1.5f);
					ship.getMutableStats().getMissileRoFMult().modifyMult(id, 1.5f);
					ship.getMutableStats().getMissileWeaponDamageMult().modifyMult(id, 1.5f);

					if (systemState == 1) {
						ship.setJitter(stats.getEntity(), FULL_COLOR, 1f, 7, 3f, 10f);
					}

					if (systemState == 2) {
						//Global.getLogger(GamalielSystemStats.class).info("passed interval 2");
						ship.getMutableStats().getBallisticRoFMult().unmodify(id);
						ship.getMutableStats().getEnergyRoFMult().unmodify(id);
						ship.getMutableStats().getBallisticWeaponDamageMult().unmodify(id);
						ship.getMutableStats().getEnergyWeaponDamageMult().unmodify(id);
						ship.getMutableStats().getMissileRoFMult().unmodify(id);
						ship.getMutableStats().getMissileWeaponDamageMult().unmodify(id);
					}
				}
			}
		}
		
		if (state == State.OUT && fireDir != null) {
			float amount = Global.getCombatEngine().getElapsedInLastFrame();
			//ship.getVelocity().x -= fireDir.x * BACK_OFF_ACCEL * amount;
			//ship.getVelocity().y -= fireDir.y * BACK_OFF_ACCEL * amount;
			if (maxGams <8) {
				maxGams += 1;
			}
			amtGamsBirthed = 0;
			if (systemActivations <= 10 && !checkswitch) {
				systemActivations += 1;
				checkswitch = true;
			}
		}
		
		if (state == State.IDLE || state == State.COOLDOWN) {
			fireDir = null;
			elapsedActive = REFIRE_DELAY;
			// reset intervals
			interval.nextInterval();
			interval2.nextInterval();
			systemState = 0;
			/*Global.getCombatEngine().maintainStatusForPlayerShip(KEY_TARGET,
					ship.getSystem().getSpecAPI().getIconSpriteName(),
					ship.getSystem().getDisplayName(),
					"" + (int) ((ship.getMutableStats().getSystemCooldownBonus() - 1f) * 100f) + "% lower weapons firing range", true);*/
		}

		// permanent bonuses
		ship.getMutableStats().getSystemCooldownBonus().modifyFlat(id, -(5f * systemActivations));
		ship.getMutableStats().getFluxCapacity().modifyFlat(id, (500f * systemActivations));
		ship.getMutableStats().getFluxDissipation().modifyFlat(id, (50f * systemActivations));
		ship.getMutableStats().getTimeMult().modifyMult(id, 1f + (0.1f * systemActivations));
		ship.getMutableStats().getEnergyRoFMult().modifyMult(id, 1f + (0.5f * systemActivations));
		ship.getMutableStats().getBallisticRoFMult().modifyMult(id, 1f + (0.5f * systemActivations));
		ship.getMutableStats().getShieldDamageTakenMult().modifyFlat(id, (0.1f * systemActivations));
		ship.getMutableStats().getShieldUpkeepMult().modifyFlat(id, -(0.05f * systemActivations));
		// perma jitter
		ship.setJitter(ship, JITTER_UNDER_COLOR, systemActivations * 0.1f, 2 + systemActivations, 3f, 8f + systemActivations);
	}

	// shrouded ejecta effect for spawning fighters
	public static void fireShroudedEjecta(ShipAPI ship, Vector2f fireDir) {
		float dir = Misc.getAngleInDegrees(fireDir);
		CombatEngineAPI engine = Global.getCombatEngine();
		CombatFleetManagerAPI manager = engine.getFleetManager(ship.getOriginalOwner());
		manager.setSuppressDeploymentMessages(true);
		
		// wing has size 1, so no other members besides the "leader"
		// point is to spawn a ship but without it showing up in the deployment dialog etc
		ShipAPI ejecta = manager.spawnShipOrWing(OBSCENE_WING,
								ship.getLocation(), dir, 0f, null);
		manager.setSuppressDeploymentMessages(true);

		ejecta.setJitter(ejecta, JITTER_COLOR, 1, 5, 5f, 10f);
		ejecta.setJitter(ejecta, JITTER_UNDER_COLOR, 0.5f, 3, 3f, 15f);

		//Vector2f takeoffVel = Misc.getUnitVectorAtDegreeAngle(
		//						dir + LAUNCH_ARC/2f - (float) Math.random() * LAUNCH_ARC);

		// randomise takeoff angle
		Vector2f takeoffVel = Misc.getUnitVectorAtDegreeAngle(
								dir + (float) Math.floor(Math.random() * 361));

		float velMult = 5f;
		velMult = 2f + (float) Math.floor(Math.random() * 10f);
		takeoffVel.scale(ejecta.getMaxSpeed() * velMult);
		
		Vector2f.add(ejecta.getVelocity(), takeoffVel, ejecta.getVelocity());
		
		DwellerShroud shroud = DwellerShroud.getShroudFor(ejecta);
		if (shroud != null) {
			shroud.custom1 = ship;
		}
		
		DwellerShroud sourceShroud = DwellerShroud.getShroudFor(ship);
		if (sourceShroud != null) {
			Vector2f offset = Vector2f.sub(ejecta.getLocation(), sourceShroud.getAttachedTo().getLocation(), new Vector2f());
			Global.getCombatEngine().addPlugin(
					new DisturbShroudPlugin(1f, fireDir, ejecta, offset, sourceShroud, 
							(int) (sourceShroud.getNumMembersToMaintain() * 0.1f)));
			
		}

		/*Vector2f point = new Vector2f(ejecta.getLocation());
		point.x += ejecta.getCollisionRadius() * (((float) Math.random() * 2f) - 1f);
		point.y += ejecta.getCollisionRadius() * (((float) Math.random() * 2f) - 1f);

		if (decaytick.intervalElapsed()) {
			engine.applyDamage(
					ejecta,
					point,
					Float.MAX_VALUE,
					DamageType.HIGH_EXPLOSIVE,
					0f,
					true,
					false,
					ejecta);
			// reset the interval for next system use?
			decaytick.nextInterval();
		}*/

		Global.getSoundPlayer().playSound("system_tenebrous_expulsion_fire", 1f, 1f, ejecta.getLocation(), ejecta.getVelocity());
	}

	// ripped from rift cascade emitter, for use in phase 1
	/*public static NegativeExplosionVisual.NEParams createStandardRiftParams(String minelayerId, float baseRadius) {
		Color color = new Color(100,100,255,255);
		Object o = Global.getSettings().getWeaponSpec(minelayerId).getProjectileSpec();
		if (o instanceof MissileSpecAPI) {
			MissileSpecAPI spec = (MissileSpecAPI) o;
			color = spec.getGlowColor();
		}
		NegativeExplosionVisual.NEParams p = createStandardRiftParams(color, baseRadius);
		return p;
	}*/

	public static NegativeExplosionVisual.NEParams createStandardRiftParams(Color borderColor, float radius) {
		NegativeExplosionVisual.NEParams p = new NegativeExplosionVisual.NEParams();
		//p.radius = 50f;
		p.hitGlowSizeMult = .75f;
		//p.hitGlowSizeMult = .67f;
		p.spawnHitGlowAt = 0f;
		p.noiseMag = 1f;
		p.fadeIn = 0f;
		p.fadeOut = 2f;

		//p.color = new Color(175,100,255,255);

		//p.hitGlowSizeMult = .75f;
		p.fadeIn = 0.1f;
		//p.noisePeriod = 0.05f;
		p.underglow = RiftCascadeEffect.EXPLOSION_UNDERCOLOR;
		//p.withHitGlow = i == 0;
		p.withHitGlow = true;

		//p.radius = 20f;
		p.radius = radius;
		//p.radius *= 0.75f + 0.5f * (float) Math.random();

		p.color = borderColor;
		return p;
	}

	public static void spawnStandardRift(ShipAPI ship) {
		CombatEngineAPI engine = Global.getCombatEngine();
		Color color = new Color(204, 15, 114,255);
		NegativeExplosionVisual.NEParams p = createStandardRiftParams(color, 15f); //.clone() protected or some shi
		//explosion.addDamagedAlready(explosion.getSource());

		CombatEntityAPI prev = null;
		for (int i = 0; i < p.numRiftsToSpawn; i++) { // 2 by default
			p.radius *= 0.75f + 0.5f * (float) Math.random();

			p.withHitGlow = prev == null;

			Vector2f loc = new Vector2f(ship.getLocation());
			loc = Misc.getPointWithinRadius(loc, p.radius * 5f);
			loc.y += 20f; // ensure it covers ship properly
			//loc = Misc.getPointAtRadius(loc, p.radius * 0.4f);

			CombatEntityAPI e = engine.addLayeredRenderingPlugin(new NegativeExplosionVisual(p));
			e.getLocation().set(loc);

			if (prev != null) {
				float dist = Misc.getDistance(prev.getLocation(), loc);
				Vector2f vel = Misc.getUnitVectorAtDegreeAngle(Misc.getAngleInDegrees(loc, prev.getLocation()));
				vel.scale(dist / (p.fadeIn + p.fadeOut) * 0.7f);
				e.getVelocity().set(vel);
			}

			prev = e;
		}

	}

	// unique phase trail
	public static void spawnPhaseTrail(ShipAPI ship) {
		// to prevent timemult shenanigans
		int alpha = 100;
		double timeMult = (double) ship.getMutableStats().getTimeMult().modified;
		alpha = (int) Math.ceil(100 / timeMult);
		alpha = Math.min(alpha, 100);

		// location
		Vector2f point = new Vector2f(ship.getLocation());
		//point = Misc.getPointWithinRadius(point, 20f);

		Vector2f p = new Vector2f(0f, 0f);

		Vector2f vel = new Vector2f(-ship.getVelocity().x, -ship.getVelocity().y);

		final float angle = ship.getFacing() + 180f;

		Color color = new Color(99, 48, 121, alpha);
		SpriteAPI sprite = Global.getSettings().getSprite("sprites", "gamaliel_afterimage");

		// presumably based on the width and height of the glow sprite
		Vector2f size = new Vector2f(sprite.getWidth(), sprite.getHeight());

		// spawn multiple to make jitter - does not work, replaced by below
		//MagicRender.singleframe(sprite, point, size, ship.getFacing() - 90f, color, true);
		//MagicRender.singleframe(sprite, point, size, ship.getFacing() - 90f, color, true);
		//MagicRender.singleframe(sprite, point, size, ship.getFacing() - 90f, color, true);

		//sprite.setColor(color);
		//sprite.renderAtCenter(point.x, point.y);
		//sprite.renderRegionAtCenter(point.x, point.y, 3f, 3f,0f,0f);

		// glow that ship leaves
		MagicRender.objectspace(
				sprite,
				ship,
				p,
				vel,
				size,
				null,
				angle,
				0f,
				false,
				color,
				true,
				0f,
				0f,
				0f,
				0f,
				0f,
				0f,
				0.1f,
				1f,
				true,
				CombatEngineLayers.BELOW_SHIPS_LAYER
    );
	}

	// unique phase glow
	public void spawnPhaseGlow(ShipAPI ship) {
		// to prevent timemult shenanigans
		int alpha = 70;
		double timeMult = (double) ship.getMutableStats().getTimeMult().modified;
		alpha = (int) Math.ceil(70 / timeMult);
		alpha = Math.min(alpha, 70);

		// location
		Vector2f point = new Vector2f(ship.getLocation());
		point = Misc.getPointWithinRadius(point, 0.4f);

		Vector2f vel = new Vector2f(-ship.getVelocity().x/3, -ship.getVelocity().y/3);

		Vector2f p = new Vector2f(0f, 0f);

		Color color = new Color(99, 48, 121, alpha);
		SpriteAPI sprite = Global.getSettings().getSprite("sprites", "gamaliel_glow");

		// presumably based on the width and height of the glow sprite
		Vector2f size = new Vector2f(sprite.getWidth(), sprite.getHeight());

		// spawn multiple to make jitter - does not work, replaced by below
		//MagicRender.singleframe(sprite, point, size, ship.getFacing() - 90f, color, true);
		//MagicRender.singleframe(sprite, point, size, ship.getFacing() - 90f, color, true);
		//MagicRender.singleframe(sprite, point, size, ship.getFacing() - 90f, color, true);

		//sprite.setColor(color);
		//sprite.renderAtCenter(point.x, point.y);
		//sprite.renderRegionAtCenter(point.x, point.y, 3f, 3f,0f,0f);

		// glow that stays on ship
		MagicRender.objectspace(
				sprite,
				ship,
				p,
				p,
				size,
				null,
				ship.getFacing() + 180f,
				0f,
				false,
				color,
				true,
				0f,
				2f,
				0.1f,
				true
		);
	}

	@Override
	public StatusData getStatusData(int index, State state, float effectLevel) {
		if (index == 0) {
			return new StatusData("Ship gains permanent bonuses every shipsystem activation", false);
		}
		if (index == 1) {
			return new StatusData("Shipsystem has been activated " + (systemActivations) + " times", false);
		}
		return null;
	}
	
}








