package DE.combat;

import java.util.List;

import java.awt.Color;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.combat.ShipSystemAPI.SystemState;
import com.fs.starfarer.api.combat.ShipwideAIFlags.AIFlags;
import com.fs.starfarer.api.impl.campaign.ids.Personalities;
import com.fs.starfarer.api.input.InputEventAPI;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.impl.combat.BaseShipSystemScript;
import com.fs.starfarer.combat.ai.BasicShipAI;

public class LionsBaffleStats extends BaseShipSystemScript {
	public static Object KEY_SHIP = new Object();
	public static Object KEY_TARGET = new Object();
	
	public static float RANGE_NEGATIVE_MULT = 0.5f;
	protected static float RANGE = 1500f;
	
	public static Color TEXT_COLOR = new Color(252, 110, 188,255);

	public static final Color JITTER_COLOR = new Color(200,0,120,255);
	public static Color JITTER_UNDER_COLOR = new Color(255,50,50,75);
	protected ShipAIConfig origConfig;


	public static class TargetData {
		public ShipAPI ship;
		public ShipAPI target;
		public EveryFrameCombatPlugin targetEffectPlugin;
		public float elaspedAfterInState;
		public TargetData(ShipAPI ship, ShipAPI target) {
			this.ship = ship;
			this.target = target;
		}
	}
	
	// apply
	public void apply(MutableShipStatsAPI stats, final String id, State state, float effectLevel) {
		ShipAPI ship = null;
		if (stats.getEntity() instanceof ShipAPI) {
			ship = (ShipAPI) stats.getEntity();
		} else {
			return;
		}
		
		final String targetDataKey = ship.getId() + "_lionsbaffle_target_data";
		
		Object targetDataObj = Global.getCombatEngine().getCustomData().get(targetDataKey); 
		if (state == State.IN && targetDataObj == null) {
			ShipAPI target = findTarget(ship);
			Global.getCombatEngine().getCustomData().put(targetDataKey, new TargetData(ship, target));
			if (target != null) {
				if (target.getFluxTracker().showFloaty() || 
						ship == Global.getCombatEngine().getPlayerShip() ||
						target == Global.getCombatEngine().getPlayerShip()) {
					target.getFluxTracker().showOverloadFloatyIfNeeded("Lion's Roar!", TEXT_COLOR, 4f, true);
				}
			}
		} else if (state == State.IDLE && targetDataObj != null) {
			Global.getCombatEngine().getCustomData().remove(targetDataKey);
			targetDataObj = null;
		}
		if (targetDataObj == null || ((TargetData) targetDataObj).target == null) return;
		
		final TargetData targetData = (TargetData) targetDataObj;
		//System.out.println("targetData.currDamMult: " + targetData.currDamMult);
		if (targetData.targetEffectPlugin == null) {
			targetData.targetEffectPlugin = new BaseEveryFrameCombatPlugin() {
				@Override
				public void advance(float amount, List<InputEventAPI> events) {
					ShipAIPlugin AItype = targetData.target.getShipAI();
					if (Global.getCombatEngine().isPaused()) return;
					if (targetData.target == Global.getCombatEngine().getPlayerShip()) {
						targetData.target.getMutableStats().getBallisticWeaponRangeBonus().modifyMult(id, RANGE_NEGATIVE_MULT);
						targetData.target.getMutableStats().getEnergyWeaponRangeBonus().modifyMult(id, RANGE_NEGATIVE_MULT);
						targetData.target.getMutableStats().getMissileWeaponRangeBonus().modifyMult(id, RANGE_NEGATIVE_MULT);
						Global.getCombatEngine().maintainStatusForPlayerShip(KEY_TARGET,
								targetData.ship.getSystem().getSpecAPI().getIconSpriteName(),
								targetData.ship.getSystem().getDisplayName(),
								"" + (int) ((RANGE_NEGATIVE_MULT - 1f) * 100f) + "% lower weapons firing range", true);
				}

					if (AItype == null) {
						return;
					}
					ShipAIConfig config = AItype.getConfig();
					if (config == null) {
						return;
					}
					origConfig = config.clone();
					if (state == State.COOLDOWN || !targetData.ship.isAlive()) {

						targetData.target.getAIFlags().unsetFlag(AIFlags.RUN_QUICKLY);
						targetData.target.getAIFlags().unsetFlag(AIFlags.BACK_OFF);
						targetData.target.getAIFlags().unsetFlag(AIFlags.BACKING_OFF);
						targetData.target.getAIFlags().unsetFlag(AIFlags.DO_NOT_VENT);
						targetData.target.getAIFlags().unsetFlag(AIFlags.IN_CRITICAL_DPS_DANGER);
						targetData.target.getAIFlags().unsetFlag(AIFlags.IGNORES_ORDERS);
						// reset to OG personality
						config.copyFrom(origConfig);
						// Global.getLogger(LionsBaffleStats.class).info("lionsbaffle return values procced");

						Global.getCombatEngine().removePlugin(targetData.targetEffectPlugin);
						} else {

						if (state == State.IN && targetData.target != Global.getCombatEngine().getPlayerShip()) {
								// timid conversion may not be reversible so avoid that
								config.personalityOverride = Personalities.TIMID;
								targetData.target.getAIFlags().setFlag(AIFlags.RUN_QUICKLY);
								targetData.target.getAIFlags().setFlag(AIFlags.BACK_OFF);
								targetData.target.getAIFlags().setFlag(AIFlags.BACKING_OFF);
								targetData.target.getAIFlags().setFlag(AIFlags.DO_NOT_VENT);
								targetData.target.getAIFlags().setFlag(AIFlags.IN_CRITICAL_DPS_DANGER);
								targetData.target.getAIFlags().setFlag(AIFlags.IGNORES_ORDERS);
							} else {
								return;
							}
						}
				}
			};
			Global.getCombatEngine().addPlugin(targetData.targetEffectPlugin);
		}
		
		
		if (effectLevel > 0) {
			if (state != State.IN) {
				targetData.elaspedAfterInState += Global.getCombatEngine().getElapsedInLastFrame();
			}
			float shipJitterLevel = 0;
			if (state == State.IN) {
				shipJitterLevel = effectLevel;
			} else {
				float durOut = 0.5f;
				shipJitterLevel = Math.max(0, durOut - targetData.elaspedAfterInState) / durOut;
			}
			float targetJitterLevel = effectLevel;
			
			float maxRangeBonus = 50f;
			float jitterRangeBonus = shipJitterLevel * maxRangeBonus;
			
			Color color = JITTER_COLOR;
			if (shipJitterLevel > 0) {
				//ship.setJitterUnder(KEY_SHIP, JITTER_UNDER_COLOR, shipJitterLevel, 21, 0f, 3f + jitterRangeBonus);
				ship.setJitter(KEY_SHIP, color, shipJitterLevel, 4, 0f, 0 + jitterRangeBonus * 1f);
			}
			
			if (targetJitterLevel > 0) {
				//target.setJitterUnder(KEY_TARGET, JITTER_UNDER_COLOR, targetJitterLevel, 5, 0f, 15f);
				targetData.target.setJitter(KEY_TARGET, color, targetJitterLevel, 3, 0f, 5f);
			}
		}
	}
	
	
	public void unapply(MutableShipStatsAPI stats, String id) {
		
	}
	
	protected ShipAPI findTarget(ShipAPI ship) {
		float range = getMaxRange(ship);
		boolean player = ship == Global.getCombatEngine().getPlayerShip();
		ShipAPI target = ship.getShipTarget();
		
		if (ship.getShipAI() != null && ship.getAIFlags().hasFlag(AIFlags.TARGET_FOR_SHIP_SYSTEM)){
			target = (ShipAPI) ship.getAIFlags().getCustom(AIFlags.TARGET_FOR_SHIP_SYSTEM);
		}
		
		if (target != null) {
			float dist = Misc.getDistance(ship.getLocation(), target.getLocation());
			float radSum = ship.getCollisionRadius() + target.getCollisionRadius();
			if (dist > range + radSum) target = null;
		} else {
			if (target == null || target.getOwner() == ship.getOwner()) {
				if (player) {
					target = Misc.findClosestShipEnemyOf(ship, ship.getMouseTarget(), HullSize.FRIGATE, range, true);
				} else {
					Object test = ship.getAIFlags().getCustom(AIFlags.MANEUVER_TARGET);
					if (test instanceof ShipAPI) {
						target = (ShipAPI) test;
						float dist = Misc.getDistance(ship.getLocation(), target.getLocation());
						float radSum = ship.getCollisionRadius() + target.getCollisionRadius();
						if (dist > range + radSum || target.isFighter()) target = null;
					}
				}
			}
		}
		
		if (target != null && target.isFighter()) target = null;
		if (target == null) {
			target = Misc.findClosestShipEnemyOf(ship, ship.getLocation(), HullSize.FRIGATE, range, true);
		}
		
		return target;
	}
	
	
	public static float getMaxRange(ShipAPI ship) {
		return ship.getMutableStats().getSystemRangeBonus().computeEffective(RANGE);
	}

	
	public StatusData getStatusData(int index, State state, float effectLevel) {
		if (effectLevel > 0) {
			if (index == 0) {
				// note to self change this
				float damMult = 1f + (RANGE_NEGATIVE_MULT - 1f) * effectLevel;
				return new StatusData("" + (int)((damMult - 1f) * 100f) + "% more damage to target", false);
			}
		}
		return null;
	}


	@Override
	public String getInfoText(ShipSystemAPI system, ShipAPI ship) {
		if (system.isOutOfAmmo()) return null;
		if (system.getState() != SystemState.IDLE) return null;
		
		ShipAPI target = findTarget(ship);
		if (target != null && target != ship) {
			return "READY";
		}
		if ((target == null) && ship.getShipTarget() != null) {
			return "OUT OF RANGE";
		}
		return "NO TARGET";
	}

	
	@Override
	public boolean isUsable(ShipSystemAPI system, ShipAPI ship) {
		//if (true) return true;
		ShipAPI target = findTarget(ship);
		return target != null && target != ship;
	}

}








