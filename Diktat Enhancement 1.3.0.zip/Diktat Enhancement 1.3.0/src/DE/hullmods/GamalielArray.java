package DE.hullmods;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import com.fs.starfarer.api.impl.hullmods.BaseLogisticsHullMod;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.plugins.ShipSystemStatsScript;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import DE.scripts.DE_ModPlugin;

import java.awt.*;

// for anyone trying to access this, this hullmod DOES NOT PERFORM ANY OF THE RAMP EFFECTS, IT IS ALL SMOKE AND MIRRORS FOR DISPLAY PURPOSES
// actual code for ramp effects is in GamalielSystemStats
public class GamalielArray extends BaseHullMod {

	public static float ENGINE_HEALTH_BONUS = 100f;
	public static float WEAPON_HEALTH_BONUS = 100f;
	public static float CORONA_EFFECT_MULT = 0.25f;
	public static float FLUX_CAP_FLAT = 500f;
	public static float FLUX_DISS_FLAT = 50f;
	public static float TIME_MULT = 10f;
	public static float ROF_MULT = 50f;
	public static float SHIELD_EFF_MULT = 10f;
	public static float SHIELD_UPKEEP_MULT = 5f;
	public static float MAX_SYSTEM = 10f;
	public static float SYSTEM_COOLDOWN_BONUS = 5f;
	public static float SYSTEM_COOLDOWN_MIN = 25f;
	public static float SPAWN_BONUS = 1f;
	public static float SPAWN_MAX = 8f;

	// taken from Sierra's Concord - thanks Raccoon
	public void advanceInCampaign(FleetMemberAPI member, float amount) {
		PersonAPI gamaliel = Global.getSector().getImportantPeople().getPerson(DE_ModPlugin.Gamaliel);

		if (gamaliel == null || Global.getSector().getPlayerFleet() == null || Global.getSector().getPlayerPerson() == null) {
			return;
		}

		if (member.getCaptain() != gamaliel &&
				//member.getCaptain() != Global.getSector().getPlayerPerson() &&
				Global.getSector().getPlayerFleet().getFleetData().getMembersListCopy().contains(member)) {
			member.setCaptain(gamaliel);
			//Global.getLogger(GamalielArray.class).info("added gammy cap");
		}
	}

	public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
		
		stats.getEngineHealthBonus().modifyPercent(id, ENGINE_HEALTH_BONUS);
		stats.getWeaponHealthBonus().modifyPercent(id, WEAPON_HEALTH_BONUS);
		float mult = CORONA_EFFECT_MULT;
		stats.getDynamic().getStat(Stats.CORONA_EFFECT_MULT).modifyMult(id, mult);

	}

	public String getDescriptionParam(int index, HullSize hullSize) {
		if (index == 0) return "" + (int) ENGINE_HEALTH_BONUS + "%";
		if (index == 1) return "" + (int) WEAPON_HEALTH_BONUS + "%";
		if (index == 2) return "" + 75 + "%";

		return null;
	}

	// smoke and mirrors
	@Override
	public void addPostDescriptionSection(TooltipMakerAPI tooltip, HullSize hullSize, ShipAPI ship, float width, boolean isForModSpec) {
		float pad = 3f;
		float opad = 10f;
		Color h = Misc.getHighlightColor();
		Color bad = Misc.getNegativeHighlightColor();
		Color t = Misc.getTextColor();
		Color g = Misc.getGrayColor();

/* // ref
if (index == 3) return "" + (int) FLUX_CAP_FLAT;
		if (index == 4) return "" + (int) FLUX_DISS_FLAT;
		if (index == 5) return "" + (int) Math.round((1f - TIME_MULT) * 100f) + "%";
		if (index == 6) return "" + (int) Math.round((1f - ROF_MULT) * 100f) + "%";
		if (index == 7) return "" + (int) Math.round((1f - SHIELD_EFF_MULT) * 100f) + "%";
		if (index == 8) return "" + (int) Math.round((1f - SHIELD_UPKEEP_MULT) * 100f) + "%";
		if (index == 9) return "" + (int) MAX_SYSTEM;
		if (index == 10) return "" + (int) SYSTEM_COOLDOWN_BONUS;
		if (index == 11) return "" + (int) SYSTEM_COOLDOWN_MIN;
		if (index == 12) return "" + (int) SPAWN_BONUS;
		if (index == 13) return "" + (int) SPAWN_MAX;
* */

		tooltip.addPara("At the core of this ship’s lobsterbrain is an energy desperate to be released; "
						+ "on every use of the ship’s shipsystem, "
						+ "this energy inundates the hull for the remainder of combat, "
						+ "permanently increasing flux capacity by %s, "
						+ "flux dissipation by %s, "
						+ "time flow by %s, "
						+ "weapons rate of fire by %s, "
						+ "shield efficiency by %s, "
						+ "and shield upkeep by %s "
						+ "for every use, up to " + (int) MAX_SYSTEM + ".",
				opad,
				h,
				"" + (int) FLUX_CAP_FLAT,
						"" + (int) FLUX_DISS_FLAT,
						"" + (int) TIME_MULT + "%",
						"" + (int) ROF_MULT + "%",
						"" + (int) SHIELD_EFF_MULT + "%",
						"" + (int) SHIELD_UPKEEP_MULT + "%",
						"" + (int) MAX_SYSTEM
		);

		tooltip.addPara("Also decreases the cooldown of the ship system by " + (int) SYSTEM_COOLDOWN_BONUS + ", "
				+ "down to a minimum of " + (int) SYSTEM_COOLDOWN_MIN + ", "
						+ "and increases the amount of manifestations released by " + (int) SPAWN_BONUS + ", "
						+ "to a maximum of " + (int) SPAWN_MAX + ".",
				opad,
				h,
				"" + (int) SYSTEM_COOLDOWN_BONUS,
				"" + (int) SYSTEM_COOLDOWN_MIN,
				"" + (int) SPAWN_BONUS,
				"" + (int) SPAWN_MAX
				);
	}

	public float getTooltipWidth() {
		return 412f;
	}


}
