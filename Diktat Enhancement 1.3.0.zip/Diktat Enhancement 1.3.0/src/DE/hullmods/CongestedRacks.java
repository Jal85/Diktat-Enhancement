package DE.hullmods;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import com.fs.starfarer.api.impl.hullmods.CompromisedStructure;
import com.fs.starfarer.api.Global;

public class CongestedRacks extends BaseHullMod {
	public static final float MISSILE_PENALTY_MULT = 0.5f;
	public static boolean checkswitch = false;
	
	public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
		ShipAPI ship = null;
		if (stats.getEntity() instanceof ShipAPI) {
			ship = (ShipAPI) stats.getEntity();
		} else {
			return;
		}
		// float mult = MISSILE_PENALTY_MULT + (1f - MISSILE_PENALTY_MULT);
		
		stats.getMissileRoFMult().modifyMult(id, MISSILE_PENALTY_MULT);
		stats.getMissileAmmoRegenMult().modifyMult(id, MISSILE_PENALTY_MULT);
	}

	/*@Override
	public void advanceInCombat(ShipAPI ship, float amount) {
		for (WeaponAPI w : ship.getAllWeapons()) {
			if (w.getType() != WeaponAPI.WeaponType.MISSILE) continue;

			if (w.getType() == WeaponAPI.WeaponType.MISSILE && !checkswitch) {
				float refiredelay = w.getRefireDelay();
				Global.getLogger(CongestedRacks.class).info(refiredelay);
				Global.getLogger(CongestedRacks.class).info(w.getCooldown());
				w.setRefireDelay(refiredelay * 2f);
				Global.getLogger(CongestedRacks.class).info("procced effect");
				Global.getLogger(CongestedRacks.class).info(w.getId());
				Global.getLogger(CongestedRacks.class).info(w.getRefireDelay());
				w.setRemainingCooldownTo(w.getCooldown() * 2f);
				Global.getLogger(CongestedRacks.class).info(w.getCooldown());
				checkswitch = true;
			}
		}
	}*/
	
	public String getDescriptionParam(int index, HullSize hullSize, ShipAPI ship) {
		float effect = 1f;
		if (ship != null) effect = ship.getMutableStats().getDynamic().getValue(Stats.DMOD_EFFECT_MULT);
		float mult = MISSILE_PENALTY_MULT + (1f - MISSILE_PENALTY_MULT) * (1f - effect);
		
		if (index == 0) return "" + (int) Math.round((1f - mult) * 100f) + "%";
		return null;
	}
}
