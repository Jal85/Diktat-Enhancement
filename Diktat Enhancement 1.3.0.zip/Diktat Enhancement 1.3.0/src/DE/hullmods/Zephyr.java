package DE.hullmods;

import java.awt.Color;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.combat.WeaponAPI.WeaponType;
import com.fs.starfarer.api.combat.listeners.WeaponBaseRangeModifier;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;

public class Zephyr extends BaseHullMod {
	public static float BASE_MOVEMENT_BONUS = 10;
	public static float SEVENTYFIVE_MOVEMENT_BONUS = 20;
	public static float FIFTY_MOVEMENT_BONUS = 30;
	public static float TWENTYFIVE_MOVEMENT_BONUS = 40;
	public static float CREWED_MOVEMENT_BONUS = 5;
	public static float CREWED_SEVENTYFIVE_MOVEMENT_BONUS = 10;
	public static float CREWED_FIFTY_MOVEMENT_BONUS = 15;
	public static float CREWED_TWENTYFIVE_MOVEMENT_BONUS = 20;
	public static float CREW_CASUALTIES = 50;
	
	public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
		if (!Misc.isAutomated(stats)) {
			stats.getCrewLossMult().modifyPercent(id, CREW_CASUALTIES);
			stats.getMaxSpeed().modifyPercent(id, CREWED_MOVEMENT_BONUS);
			stats.getAcceleration().modifyPercent(id, CREWED_MOVEMENT_BONUS);
			stats.getDeceleration().modifyPercent(id, CREWED_MOVEMENT_BONUS);
			stats.getTurnAcceleration().modifyPercent(id, CREWED_MOVEMENT_BONUS);
			stats.getMaxTurnRate().modifyPercent(id, CREWED_MOVEMENT_BONUS);
		} else {
			stats.getMaxSpeed().modifyPercent(id, BASE_MOVEMENT_BONUS);
			stats.getAcceleration().modifyPercent(id, BASE_MOVEMENT_BONUS);
			stats.getDeceleration().modifyPercent(id, BASE_MOVEMENT_BONUS);
			stats.getTurnAcceleration().modifyPercent(id, BASE_MOVEMENT_BONUS);
			stats.getMaxTurnRate().modifyPercent(id, BASE_MOVEMENT_BONUS);
		}
	}

	@Override
	public void advanceInCombat(ShipAPI ship, float amount) {
		float maxHull = ship.getHullLevelAtDeployment();
		MutableShipStatsAPI stats = ship.getMutableStats();
		String id = "_zephyr_effect";
		// at 75% hull
		if (!Misc.isAutomated(ship)) {
		if (ship.getHullLevel()/maxHull <= 0.75f) {
			stats.getMaxSpeed().unmodify();
			stats.getAcceleration().unmodify();
			stats.getDeceleration().unmodify();
			stats.getTurnAcceleration().unmodify();
			stats.getMaxTurnRate().unmodify();
			stats.getMaxSpeed().modifyPercent(id, CREWED_SEVENTYFIVE_MOVEMENT_BONUS);
			stats.getAcceleration().modifyPercent(id, CREWED_SEVENTYFIVE_MOVEMENT_BONUS);
			stats.getDeceleration().modifyPercent(id, CREWED_SEVENTYFIVE_MOVEMENT_BONUS);
			stats.getTurnAcceleration().modifyPercent(id, CREWED_SEVENTYFIVE_MOVEMENT_BONUS);
			stats.getMaxTurnRate().modifyPercent(id, CREWED_SEVENTYFIVE_MOVEMENT_BONUS);
		}
		// at 50% hull
		if (ship.getHullLevel()/maxHull <= 0.5f) {
			stats.getMaxSpeed().unmodify();
			stats.getAcceleration().unmodify();
			stats.getDeceleration().unmodify();
			stats.getTurnAcceleration().unmodify();
			stats.getMaxTurnRate().unmodify();
			stats.getMaxSpeed().modifyPercent(id, CREWED_FIFTY_MOVEMENT_BONUS);
			stats.getAcceleration().modifyPercent(id, CREWED_FIFTY_MOVEMENT_BONUS);
			stats.getDeceleration().modifyPercent(id, CREWED_FIFTY_MOVEMENT_BONUS);
			stats.getTurnAcceleration().modifyPercent(id, CREWED_FIFTY_MOVEMENT_BONUS);
			stats.getMaxTurnRate().modifyPercent(id, CREWED_FIFTY_MOVEMENT_BONUS);
		}
		// at 25% hull
		if (ship.getHullLevel()/maxHull <= 0.25f) {
			stats.getMaxSpeed().unmodify();
			stats.getAcceleration().unmodify();
			stats.getDeceleration().unmodify();
			stats.getTurnAcceleration().unmodify();
			stats.getMaxTurnRate().unmodify();
			stats.getMaxSpeed().modifyPercent(id, CREWED_TWENTYFIVE_MOVEMENT_BONUS);
			stats.getAcceleration().modifyPercent(id, CREWED_TWENTYFIVE_MOVEMENT_BONUS);
			stats.getDeceleration().modifyPercent(id, CREWED_TWENTYFIVE_MOVEMENT_BONUS);
			stats.getTurnAcceleration().modifyPercent(id, CREWED_TWENTYFIVE_MOVEMENT_BONUS);
			stats.getMaxTurnRate().modifyPercent(id, CREWED_TWENTYFIVE_MOVEMENT_BONUS);
		}
	} else {
			if (ship.getHullLevel()/maxHull <= 0.75f) {
				stats.getMaxSpeed().unmodify();
				stats.getAcceleration().unmodify();
				stats.getDeceleration().unmodify();
				stats.getTurnAcceleration().unmodify();
				stats.getMaxTurnRate().unmodify();
				stats.getMaxSpeed().modifyPercent(id, SEVENTYFIVE_MOVEMENT_BONUS);
				stats.getAcceleration().modifyPercent(id, SEVENTYFIVE_MOVEMENT_BONUS);
				stats.getDeceleration().modifyPercent(id, SEVENTYFIVE_MOVEMENT_BONUS);
				stats.getTurnAcceleration().modifyPercent(id, SEVENTYFIVE_MOVEMENT_BONUS);
				stats.getMaxTurnRate().modifyPercent(id, SEVENTYFIVE_MOVEMENT_BONUS);
			}
			// at 50% hull
			if (ship.getHullLevel()/maxHull <= 0.5f) {
				stats.getMaxSpeed().unmodify();
				stats.getAcceleration().unmodify();
				stats.getDeceleration().unmodify();
				stats.getTurnAcceleration().unmodify();
				stats.getMaxTurnRate().unmodify();
				stats.getMaxSpeed().modifyPercent(id, FIFTY_MOVEMENT_BONUS);
				stats.getAcceleration().modifyPercent(id, FIFTY_MOVEMENT_BONUS);
				stats.getDeceleration().modifyPercent(id, FIFTY_MOVEMENT_BONUS);
				stats.getTurnAcceleration().modifyPercent(id, FIFTY_MOVEMENT_BONUS);
				stats.getMaxTurnRate().modifyPercent(id, FIFTY_MOVEMENT_BONUS);
			}
			// at 25% hull
			if (ship.getHullLevel()/maxHull <= 0.25f) {
				stats.getMaxSpeed().unmodify();
				stats.getAcceleration().unmodify();
				stats.getDeceleration().unmodify();
				stats.getTurnAcceleration().unmodify();
				stats.getMaxTurnRate().unmodify();
				stats.getMaxSpeed().modifyPercent(id, TWENTYFIVE_MOVEMENT_BONUS);
				stats.getAcceleration().modifyPercent(id, TWENTYFIVE_MOVEMENT_BONUS);
				stats.getDeceleration().modifyPercent(id, TWENTYFIVE_MOVEMENT_BONUS);
				stats.getTurnAcceleration().modifyPercent(id, TWENTYFIVE_MOVEMENT_BONUS);
				stats.getMaxTurnRate().modifyPercent(id, TWENTYFIVE_MOVEMENT_BONUS);
			}
		}
		if (!ship.isAlive()) {
			stats.getMaxSpeed().unmodify();
			stats.getAcceleration().unmodify();
			stats.getDeceleration().unmodify();
			stats.getTurnAcceleration().unmodify();
			stats.getMaxTurnRate().unmodify();
		}
	}

	public String getDescriptionParam(int index, HullSize hullSize) {
		return null;
	}
	
	@Override
	public boolean shouldAddDescriptionToTooltip(HullSize hullSize, ShipAPI ship, boolean isForModSpec) {
		return false;
	}

	@Override
	public void addPostDescriptionSection(TooltipMakerAPI tooltip, HullSize hullSize, ShipAPI ship, float width, boolean isForModSpec) {
		float pad = 3f;
		float opad = 10f;
		Color h = Misc.getHighlightColor();
		Color bad = Misc.getNegativeHighlightColor();

		tooltip.addPara("Originally developed by Tri-Tachyon on use for droneships deemed as high-valued assets, "
						+ "the “Zephyr” is the sales name of a vast array of ship-wide maneuvering air jets installed post-production on a hull. "
						+ "With self-contained fuel tanks and a ship-wide network, "
						+ "the system can rapidly respond to and dodge incoming threats, "
						+ "increasing maneuverability and top speed by %s. "
						+ "Furthermore, the system is designed to express itself more actively as hull integrity degrades, "
						+ "increasing movement by %s "
						+ "/ %s "
						+ "/ %s "
						+ "for every %s "
						+ "hull lost in combat. ",
				opad, h,
				"" + (int)BASE_MOVEMENT_BONUS + "%",
						"" + (int)SEVENTYFIVE_MOVEMENT_BONUS + "%",
						"" + (int)FIFTY_MOVEMENT_BONUS + "%",
						"" + (int)TWENTYFIVE_MOVEMENT_BONUS + "%",
						"" + 25 + "%"
		);
		
		if (!Misc.isAutomated(ship)) {
			tooltip.addPara("In the absence of AI control, "
							+ "the jets are independently handled by several delta-AI cores, overseen from the bridge. "
							+ "This reduces the reaction time of the system at large, "
							+ "reducing the movement bonuses to %s "
							+ "/ %s "
							+ "/ %s "
							+ "/ %s."
					, opad, h,
					"" + (int)CREWED_MOVEMENT_BONUS + "%",
							"" + (int)CREWED_SEVENTYFIVE_MOVEMENT_BONUS + "%",
							"" + (int)CREWED_FIFTY_MOVEMENT_BONUS + "%",
							"" + (int)CREWED_TWENTYFIVE_MOVEMENT_BONUS + "%"
			);
			tooltip.addPara("Furthermore, the sudden movements are more likely to cause adverse incidents in maintainence shafts and hallways, "
					+ "increasing crew casualties in combat by %s.", opad, h,
					"" + (int) CREW_CASUALTIES + "%");
		}
	}
	
//	@Override
//	public boolean isApplicableToShip(ShipAPI ship) {
//		return getUnapplicableReason(ship) == null;
//	}
//	
//	public String getUnapplicableReason(ShipAPI ship) {
//		if (ship != null && 
//				ship.getHullSize() != HullSize.CAPITAL_SHIP && 
//				ship.getHullSize() != HullSize.DESTROYER && 
//				ship.getHullSize() != HullSize.CRUISER) {
//			return "Can only be installed on destroyer-class hulls and larger";
//		}
//		return null;
//	}
	
}









