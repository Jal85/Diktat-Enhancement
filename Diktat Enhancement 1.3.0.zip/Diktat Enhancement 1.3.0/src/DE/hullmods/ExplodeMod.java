package DE.hullmods;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.graphics.SpriteAPI;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import com.fs.starfarer.api.util.IntervalUtil;
import com.fs.starfarer.api.util.Misc;
import org.lwjgl.util.vector.Vector2f;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import org.magiclib.util.MagicRender;

import java.awt.*;

public class ExplodeMod extends BaseHullMod {

	public static final float RADIUS_MULT = 0.25f;
	public static final float DAMAGE_MULT = 0.1f;
	public static final Color JITTER_UNDER_COLOR = new Color(99, 48, 121, 255);
	protected float timeToDie = 0f;
	private final IntervalUtil tracker = new IntervalUtil(20f, 20f);

	@Override
	public void advanceInCombat(ShipAPI ship, float amount) {
		CombatEngineAPI engine = Global.getCombatEngine();
		Vector2f point = new Vector2f(ship.getLocation());
		point.x += ship.getCollisionRadius() * (((float) Math.random() * 2f) - 1f);
		point.y += ship.getCollisionRadius() * (((float) Math.random() * 2f) - 1f);

		tracker.advance(amount);
		//Global.getLogger(ExplodeMod.class).info("explosion timer ticking");

		timeToDie = tracker.getElapsed();
		ship.setJitter(ship, JITTER_UNDER_COLOR, timeToDie * 0.1f, 3 + (int) timeToDie, 3f, 8f + timeToDie);

		// spawn same trails as Gamaliel
		spawnPhaseTrail(ship);

		if (tracker.intervalElapsed()) {
			ship.getFluxTracker().showOverloadFloatyIfNeeded("Dissolution!", JITTER_UNDER_COLOR, 4f, true);
			//Global.getLogger(ExplodeMod.class).info("explosion timer pass");
			engine.applyDamage(
					ship,
					point,
					Float.MAX_VALUE,
					DamageType.HIGH_EXPLOSIVE,
					0f,
					true,
					false,
					ship);
			engine.removeEntity(ship);
		}
	}

	// unique phase trail
	public static void spawnPhaseTrail(ShipAPI ship) {
		// to prevent timemult shenanigans
		/*int alpha = 225;
		double timeMult = (double) ship.getMutableStats().getTimeMult().modified;
		alpha = (int) Math.ceil(225 / timeMult);
		alpha = Math.min(alpha, 255);*/

		// location
		Vector2f point = new Vector2f(ship.getLocation());
		point = Misc.getPointWithinRadius(point, 20f);

		Vector2f p = new Vector2f(0f, 0f);

		Vector2f vel = new Vector2f(-ship.getVelocity().x, -ship.getVelocity().y);

		final float angle = ship.getFacing() + 180f;

		Color color = new Color(99, 48, 121, 50);
		SpriteAPI sprite = Global.getSettings().getSprite("sprites", "gamaliel_afterimage");

		// presumably based on the width and height of the glow sprite
		Vector2f size = new Vector2f(sprite.getWidth(), sprite.getHeight());

		// spawn multiple to make jitter - does not work, replaced by below
		//MagicRender.singleframe(sprite, point, size, ship.getFacing() - 90f, color, true);
		//MagicRender.singleframe(sprite, point, size, ship.getFacing() - 90f, color, true);
		//MagicRender.singleframe(sprite, point, size, ship.getFacing() - 90f, color, true);

		//sprite.setColor(color);
		//sprite.renderAtCenter(point.x, point.y);
		//sprite.renderRegionAtCenter(point.x, point.y, 3f, 3f,0f,0f);

		// glow that ship leaves
		MagicRender.objectspace(
				sprite,
				ship,
				p,
				vel,
				size,
				null,
				angle,
				0f,
				false,
				color,
				true,
				0f,
				0f,
				0f,
				0f,
				0f,
				0f,
				0.1f,
				1f,
				true,
				CombatEngineLayers.BELOW_SHIPS_LAYER
		);
	}

	public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
		stats.getDynamic().getStat(Stats.EXPLOSION_DAMAGE_MULT).modifyMult(id, DAMAGE_MULT);
		stats.getDynamic().getStat(Stats.EXPLOSION_RADIUS_MULT).modifyMult(id, RADIUS_MULT);
	}
	
	public String getDescriptionParam(int index, HullSize hullSize) {
		return null;
	}


}
