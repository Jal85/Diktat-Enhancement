package DE.hullmods;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.impl.campaign.ids.Stats;

public class QliphothArray extends BaseHullMod {

	public static final float MAX_CR_INCREASE = 30f;
	public static final float DEGRADE_INCREASE_PERCENT = 50f;
	private static final float MALFUNCTION_FLAT = 0.5f;
	
	public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
		stats.getMaxCombatReadiness().modifyFlat(id, MAX_CR_INCREASE);
		stats.getCRLossPerSecondPercent().modifyPercent(id, DEGRADE_INCREASE_PERCENT);
		stats.getCriticalMalfunctionChance().modifyFlat(id, MALFUNCTION_FLAT);
	}
	
	public String getDescriptionParam(int index, HullSize hullSize) {
		if (index == 0) return "" + (int) MAX_CR_INCREASE + "%";
		if (index == 1) return "" + (int) DEGRADE_INCREASE_PERCENT + "%";
		if (index == 2) return "" + (int) (MALFUNCTION_FLAT * 100) + "%";
		// smoke and mirrors for now...since other ships aren't implemented yet
		if (index == 3) return "" + 1 + "%";
		if (index == 4) return "" + 2 + "%";
		if (index == 5) return "" + 1 + "%";
		return null;
	}

	/*public boolean isApplicableToShip(ShipAPI ship) {
		return ship != null && (ship.getHullSpec().getNoCRLossTime() < 10000 || ship.getHullSpec().getCRLossPerSecond(ship.getMutableStats()) > 0); 
	}*/
}
