package DE.scripts;

import com.fs.starfarer.api.impl.campaign.econ.BaseHazardCondition;



public class DE_Titanlober extends BaseHazardCondition {
	
	public void apply(String id) {
		super.apply(id);
	}

	public void unapply(String id) {
		super.unapply(id);
	}

}
